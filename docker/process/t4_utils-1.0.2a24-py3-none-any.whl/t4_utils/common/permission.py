#!/usr/bin/env python3
"""
Program name:       permission.py

Date:               30 August, 2021

History:            First version

Authors:            Ramaswamy Tiruchirapalli

Email:              ramaswamy.tiruchirapalli@noaa.gov

Description:
    check_permission: This function checks if a file/directory has
    given permissions. If not, it tries to set them.

    check_permissions:   This function checks if given sequence of
    files/directories have given permissions. If not, it tries to set them.

Modules/subroutines:  pathlib.Path, os, typing.Union, warnings,
collections.namedtuple
"""
from pathlib import Path
from typing import Union
import warnings
from collections import namedtuple


def check_permission(input_path: Union[str, Path], mode=0o700):
    """
    Check permissions of given file or directory matches the given octal number.
    If permissions don't match, set the given permissions, and return True
    If unable to set permissions, return False with a UserWarning.

    Parameters
    ----------
    input_path : string or Path object
        Directory or File for which permissions need to be checked or set.
    mode : Octal
        Octal number representing permissions.
        eg. for 755 -- 0o755

    Returns
    -------
    boolean
        True if given permissions exist or able to change to given permissions.

    Raises
    ------
    ValueError
        if "mode" is not a valid octal number representing unix permissions.
    TypeError
        if input_path is not of type string or Path object.
    """
    if isinstance(input_path, str):
        input_path = Path(input_path)
    if not isinstance(input_path, Path):
        raise TypeError("input_path should be of type string or Path object")
    try:
        if not input_path.exists():
            warnings.warn(f"path not found : {input_path}")
            return False
    except PermissionError:
        warnings.warn(f"Not enough permissions to access path : {input_path}")
        return False
    if mode > 0o777 or mode < 0o000:
        raise ValueError(
            "mode should be a valid octal number less than or equal to 0o777"
        )
    path_type_permission = input_path.stat().st_mode
    # Get only permission bits(last three octal digits). Ignore file types.
    path_permission = path_type_permission & 0o777
    if not path_permission == mode:
        try:
            input_path.chmod(mode)
        except PermissionError:
            warnings.warn(
                f"Unable to change permissions of path : {input_path}"
            )
            return False
        except OSError as err:
            warnings.warn(str(err))
            return False
    return True


def check_permissions(input_path: Union[str, Path, list, tuple, set],
                      mode=0o700):
    """
    Check permissions of given files or directories match the
    given octal number.
    If permissions don't match, set the given permissions,
    and return the status(True or False) and
    the list of files or directories for which permissions could not be changed.

    Parameters
    ----------
    input_path : Union[str, Path, list, tuple, set]
        Sequence of Directories/Files for which permissions need to be checked
        or set.
    mode : octal, optional
        Octal number representing permissions, by default 0o700
        eg. for 755 -- 0o755

    Returns
    -------
    namedtuple
        The status and list of failed Path/str.
            status : True means all files/directories have the given
            permissions.
                     False means permissions could not be modified for at least
                     one of the files/directories
            failed_list:
                empty list if "status" is True.
                list of failed files/directories for which permissions could
                not be modified.

    Raises
    ------
    ValueError
        if "mode" is not a valid octal number representing unix permissions.
    TypeError
        if input_path or any one of the items is not one of the following types:
            str, Path, a sequence of string or Path.
    """
    status = False
    status_message = namedtuple("status_message", "status, failed_paths")
    if mode > 0o777 or mode < 0o000:
        raise ValueError(
            "mode should be a valid octal number less than or equal to 0o777"
        )
    if isinstance(input_path, str):
        input_path = Path(input_path)
    if isinstance(input_path, Path):
        new_path_list = [input_path]
    if isinstance(input_path, (list, tuple, set)):
        # Warn if empty sequence
        if len(input_path) == 0:
            warnings.warn("Input sequence is empty")
        # Filter out only valid Path or string elements
        new_path_list = [xx for xx in input_path if isinstance(xx, Path)]
        # Get paths whose permissions cannot be changed.
        failed_path_list = list(
            filter(lambda xx: not check_permission(xx), new_path_list)
        )
        print(failed_path_list)
        # Update status if all paths have passed.
        if not failed_path_list:
            status = True
        # Raise TypeError if one of the elements in the input has wrong type.
        if len(new_path_list) != len(input_path):
            raise TypeError(
                "One or more elements in inputs is not of type string or Path"
            )
    else:
        raise TypeError(
            "Expecting input of type str, Path, list, tuple or set."
        )
    return status_message(status, failed_path_list)
