"""
This module provides functions for setting up a processing environment.
"""

import os

from pathlib import PosixPath
from typing import Union


def set_env_var(key: Union[str, int, float, PosixPath],
                value: Union[str, int, float, PosixPath]):
    """
    This function sets a temporary environment variable based on the provided
    key and value strings.

    Parameters
    ----------
    key: str, int, float, PosixPath
    Name of the environment variable to be set.

    value: str, into, float, PosixPath
    Value of the environment variable to be set.
    """

    accepted_types = [str, int, float, PosixPath]
    key_type = type(key)
    value_type = type(value)

    if key_type not in accepted_types:
        raise TypeError(
            "Key needs to be type str, int, float, or Path object.")

    if value_type not in accepted_types:
        raise TypeError(
            "Value needs to be type str, int, float, or Path object.")

    os.environ[str(key)] = str(value)
