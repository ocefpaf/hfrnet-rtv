"""
log_handler.py provides functions to streamline and standardize usage
of the logging module

Can be used to return a logging object that has both a file handler
and a stream handler attached at logging level of INFO
"""
import sys
import logging
from io import IOBase
from pathlib import Path


def _unpack_logger(logger_arg):
    if isinstance(logger_arg, logging.Logger):
        logger = logger_arg
    elif isinstance(logger_arg, str):
        logger = logging.getLogger(logger_arg)
    else:
        raise TypeError(f'logger_arg:{logger_arg} invalid type\n'
                        f'Must be logging.Logger or str')
    return logger


def _unpack_path(path_arg):
    if isinstance(path_arg, Path):
        path = str(path_arg.resolve())
    elif isinstance(path_arg, str):
        path = str(Path(path_arg).resolve())
    else:
        raise TypeError(f'path_arg:{path_arg} invalid type\n'
                        f'Must be pathlib.Path or str')
    return path


def get_file_handler(logger_arg, path_arg):
    """
    Returns the file handler associated with logger_arg through
    path_arg or None if the path is not attached to the logger

    Parameters
    ----------
    logger_arg : logging.Logger or str
    The logger in question or the logger's string name

    path_arg : pathlib.Path or str
    The path to the log file, either represented as a pathlib.Path or
    a str

    Returns
    -------
    logging.Handler or None
        Handler for logging.FileHandlerr is returned if present otherwise None
    """
    logger = _unpack_logger(logger_arg)
    file_path = _unpack_path(path_arg)
    for handler in logger.handlers:
        if isinstance(handler, logging.FileHandler) and \
                handler.baseFilename == file_path:
            return handler
    return None


def set_file_handler(logger_arg, path_arg, level=logging.INFO,
                     fmtstr='%(asctime)s - %(name)s - %(levelname)s - %(message)s'):
    """
    Assigns the path argument as a logging.FileHandler with the given
    level and format string to the logger. If the logging file is
    already attached to the logger then it will not be reattached, but
    the existing FileHandler will have its level and format string
    reset.

    Parameters
    ----------
    logger_arg : logging.Logger or str
    The logger in question or the logger's string name

    path_arg : pathlib.Path or str
    The path to the log file, either represented as a pathlib.Path or
    a str

    level : int or str
    The logging level to be assigned to the logging.FileHandler

    fmtstr : str or None
    The format string to be assigned to the logging.FileHandler through
    a logging.Formatter. If None, then the default logging.Formatter
    will be used.
    """
    logger = _unpack_logger(logger_arg)
    file_path = _unpack_path(path_arg)
    if not isinstance(fmtstr, str):
        raise TypeError(f'fmtstr:{fmtstr} invalid type\n'
                        f'Must be str')
    if isinstance(level, str):
        level = logging.getLevelName(level)
    elif not isinstance(level, int):
        raise TypeError(f'level:{level} invalid type\n'
                        f'Must be int or str')

    file_handler = get_file_handler(logger, file_path)
    if not file_handler:
        file_handler = logging.FileHandler(file_path)
        logger.addHandler(file_handler)
    file_handler.setLevel(level)
    file_handler.setFormatter(logging.Formatter(fmtstr))


def get_stream_handler(logger_arg, stream=sys.stdout):
    """
    Returns the stream handler associated with logger_arg through
    stream or None if the stream is not attached to the logger

    Parameters
    ----------
    logger_arg : logging.Logger or str
    The logger in question or the logger's string name

    stream : io.IOBase
    The stream attached to the logger through a logging.StreamHandler
    Returns
    -------
    logging.Handler or None
        Handler for logging.StreamHandler if present otherwise returns None
    """
    logger = _unpack_logger(logger_arg)
    for handler in logger.handlers:
        if isinstance(handler, logging.StreamHandler) and \
                handler.stream == stream:
            return handler
    return None


def set_stream_handler(logger_arg, stream=sys.stdout, level=logging.INFO,
                       fmtstr='%(asctime)s - %(name)s - %(levelname)s - %(message)s'):
    """
    Assigns the stream argument as a logging.StreamHandler with the
    given level and format string to the logger. If the stream is
    already attached to the logger then it will not be reattached, but
    the existing StreamHandler will have its level and format string
    reset.

    Parameters
    ----------
    logger_arg : logging.Logger or str
    The logger in question or the logger's string name

    stream : io.IOBase
    The stream attached to the logger through a logging.StreamHandler being sent to sys.stdout

    level : int or str
    The logging level to be assigned to the logging.StreamHandler

    fmtstr : str or None
    The format string to be assigned to the logging.StreamHandler through
    a logging.Formatter. If None, then the default logging.Formatter
    will be used.
    """

    logger = _unpack_logger(logger_arg)
    if not isinstance(stream, IOBase):
        raise TypeError(f'stream:{stream} invalid type\n'
                        f'Must be IOBase')
    if not isinstance(fmtstr, str):
        raise TypeError(f'fmtstr:{fmtstr} invalid type\n'
                        f'Must be str')
    if isinstance(level, str):
        level = logging.getLevelName(level)
    elif not isinstance(level, int):
        raise TypeError(f'level:{level} invalid type\n'
                        f'Must be int or str')

    stream_handler = get_stream_handler(logger, stream)
    if not stream_handler:
        stream_handler = logging.StreamHandler(stream)
        logger.addHandler(stream_handler)
    stream_handler.setLevel(level)
    stream_handler.setFormatter(logging.Formatter(fmtstr))


def basic_logger(logger_arg, logger_path, logger_level=logging.INFO,
                 fh_level=logging.INFO, stream_level=logging.INFO):
    """
    Wrapper function that returns a logger with both file handler and
    stream handler attached

    Parameters
    ----------
    logger_arg:     logging.Logger or str
                    The str name of the logger object
    logger_path:    pathlib.Path or str
                    The path to the log file, either represented as a
                    pathlib.Path or a str
    logger_level:   int or str
                    the level of the logger specified for the overall logger
                    itself
    fh_level:       int or str
                    The level of the logger specified for logging.FileHandler
    stream_level:   int or str
                    The level of the logger specified for logging.StreamHandler
                    Stream is sent to sys.stdout
    ----------
    Returns
    -------
    logging.Logger
        Logging object with associated file handler and stream handler attached
    """

    # Set up basic logger to be used
    logger = _unpack_logger(logger_arg)

    if isinstance(logger_level, str):
        logger_level = logging.getLevelName(logger_level)
    elif not isinstance(logger_level, int):
        raise TypeError(f'level:{logger_level} invalid type\n'
                        f'Must be int or str')
    logger.setLevel(logger_level)

    # Define handlers used to output text to log files
    set_file_handler(logger_arg=logger, path_arg=logger_path, level=fh_level)
    set_stream_handler(logger_arg=logger, stream=sys.stdout, level=stream_level)

    return logger
