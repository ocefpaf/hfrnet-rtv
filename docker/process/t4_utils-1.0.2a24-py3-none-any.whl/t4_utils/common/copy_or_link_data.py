"""
Program name:       copy_or_link_data.py

Date:               31 August, 2021

History:            Edit to  allow for both strings and Path objects in:
                    source, destination or mixed as a list of source files

Authors:            Edward Borders, Trevor Clack

Email:              edward.borders@noaa.gov, trevor.clack@noaa.gov

Description:
    copy_or_link:   This function loops through a list of files and/or
directories and copies or symlinks to a specified destination using the
"copy_data" and "symlink_data" utility functions.

    copy_data :     Used as a standalone or as a recursive component
of "copy_or_link_data", this function copies files into a given
working directory. This function can also be used to copy local data
after processing into its target directory. Uses "copy_or_link_data"
util to orchestrate and allow recursion if file structure is set to
be preserved.

    symlink_data:   Used as a standalone or as a recursive component
of "copy_or_link_data", this program will create a symbolic link from
a specified source to a specified destination. By default, directory
structure is preserved from the source but may be lumped together.
In the instance of lumping, if duplicate filenames from separate
folders exist, the program will halt. An overwrite flag exists to
ignore filename collisions and continue to lump. If the destination
does not exist, this program will NOT create it.

Missing functionality: If a list of files is provided with differing
parent directories (eg. ['file1', 'dir1/file2', 'dir2/dir3/fil3']) These
will be viewed as a list of files and the "preserve_structure" will not
retain the file structure. This feature, may be useful

Modules/subroutines: shutil, pathlib
"""
import logging
from pathlib import Path
from shutil import copyfile, SameFileError
from typing import Union, Iterable

logger = logging.getLogger(__file__)


def _instance_check(instance_map):
    """Helper function to reduce clutter and branching in main functions.
    Maps a variable to a list of allowed instances. Raises exception"""
    for variable, types in instance_map:
        logger.debug('variable: %s', variable)
        logger.debug(types)
        if not isinstance(variable, types):
            allowed_types = 'or'.join([repr(typ) for typ in types])
            raise TypeError(f'"{variable}" must be of type: {allowed_types}')


def copy_or_link_data(source_list: list[Path],
                      destination: Union[Path, str], filesize_limit=None,
                      preserve_structure=True, overwrite=False):
    """
This function takes a list of files and/or directories and copies or
symlinks the contents to a target location, depending on the file size
limit set (symlinking if the filesize exceeds the set limit) Default is
None, in which case all files are copied. If the optional overwrite
flag is changed to True, the file in the destination folder with the
same file name as source will be overwritten. If the flag is set to
True and the file or directory does not exist in the destination
directory, the file is still copied.

    Parameters
    ----------
    source_list: list of Path objects or strings
        list of objects representing the locations of the files or
        directories to be copied
    destination: Path or string
        object representing the target directory of the copied
        file or directory
    filesize_limit: number (default=None)
        Optional flag. Establishes the filesize limit for copying
        files. Files at or above this limit are symlinked
    preserve_structure: boolean (default=True)
        Optional flag. Establishes whether or not the nesting of the
        source will be preserved in the destination. Setting this to
        "False" will lump all files together in the destination
    overwrite: boolean (default=False)
        Optional flag for determining if the files or directories should
        be overwritten, if a file of the same name is found in the
        destination folder, particularly if preserve_structure=False
    """
    # Make sure the types of the inputs are valid
    # Raise TypeError if destination not Path or str
    _instance_check([
        (source_list, (list)),
        (destination, (Path, str))
    ])
    # Convert destination to Path object for filehandling
    destination = Path(destination)

    # If the destination is not a valid directory, do not copy
    if not destination.exists() or destination.is_file():
        raise ValueError(f'{destination} is not a valid directory.')

    # Make sure every path in the list exists before copying.
    # Convert str paths to Path objects
    for loc, source in enumerate(source_list):
        _instance_check([(source, (str, Path))])
        if isinstance(source, str):
            source_list[loc] = Path(source)
        if not (source_list[loc]).exists():
            raise ValueError(f'{source} in source_list does not exist')

    # Copy each file to destination
    for source in source_list:
        if preserve_structure:
            new_dest = destination / source.name
        else:
            new_dest = destination
        size = source.stat().st_size
        if filesize_limit and size >= filesize_limit and source.is_file():
            # if a limit is set and the filesize exceeds the limit: symlink
            # avoid symlinking directory to maintain directory structure
            symlink_data(source, new_dest,
                         preserve_structure=preserve_structure,
                         overwrite=overwrite)
        else:
            # default - no file limit set or size is below threshold: copy
            copy_data(source, new_dest,
                      preserve_structure=preserve_structure,
                      filesize_limit=filesize_limit,
                      overwrite=overwrite)


def copy_data(source: Union[list, Path], destination: Union[Path, str],
              preserve_structure=True, filesize_limit=None, overwrite=False):
    """
This function takes a file or directory and copies the contents to a
target location. The source directory structure is preserved by default
with the preserve_structure flag. Changing it to False will lump all
files from source to the destination. This may affect data preservation
if overwrite is set to True. This however is set by default to False.
If the optional overwrite flag is changed to True, duplicate files that
are copied over to the destination will be overwritten.
    Parameters
    ----------
    source: Path, string or list of such objects
        object representing the location of the file or the directory
        to be copied. Can also be a list of Path objects
    destination: Path or string
        Target directory
    preserve_structure: boolean (default=True)
        Optional flag which determines if the nested directory structure
        from source should be preserved. setting this to False will lump
        all files from source together into the destination directory
    filesize_limit: boolean (default=None)
        IGNORE if using "copy_data" alone, this is used during the
        recursion with "copy_or_link_data". Setting a limit here will
        cause behavior similar to "copy_or_link_data"
    overwrite: boolean (default=False)
        Optional flag for determining if the file or directory should be
        overwritten, if a file of the same name is found in the
        destination folder.

    **Calling Example**
    ::
        sample_file = Path("loc/text.txt")
        sample_directory = Path("loc")
        mixed_list = ["file1.txt",Path("file2.txt"), "dir1"]
        sample_output = Path("output")

        copy_data(sample_file, sample_output)
        copy_data(sample_directory, sample_output)
        copy_data(mixed_list, sample_output)
    """
    # Raise TypeError if destination not Path or str
    _instance_check([(destination, (Path, str))])
    # Convert to Path object for filehandling
    destination = Path(destination)
    if not destination.parent.exists():
        raise NotADirectoryError(f"Destination parent {destination.parent}\
                                  does not exist. Program halting.")

    # List is provided
    if isinstance(source, list):
        copy_or_link_data(source, destination,
                          preserve_structure=preserve_structure,
                          filesize_limit=filesize_limit, overwrite=overwrite)

    # A single FILE Path object is provided
    else:
        # Raise error if source is not string or Path object
        _instance_check([(source, (Path, str))])
        # If source is a str, make it Path for file handling
        source = Path(source)
        # If either the source or destination path are not valid paths,
        # raise an Exception.
        if not source.exists():
            raise FileNotFoundError(f"Source {source} does not exist.\
                                     Program halting.")
        # If the source and the destination are the same, throw an Exception.
        # This is done to protect against unwanted file clobbering.
        if source.resolve() == destination.resolve():
            raise ValueError(f"Source {source} and destination {destination}\
                              are identical. Program halting.")
        # Only copy the file/directory if the overwrite flag is True,
        # or if the file/directory to be copied does not exist in the
        # target directory.
        if (destination / source.name).exists() and not overwrite:
            # checks for file clobbering and halts
            raise FileExistsError(f"""
"{(destination / source.name)}" already exists.
This may be due to "{source.name}" residing in separate directories
having the same name and preserve_structure flag being set to False
(which lumps all data being copied or symlinked together). The program
is halting here to prevent data loss in the new directory. If you
wish to proceed with overwriting, you may specify "overwrite=True'""")
        if source.is_file():
            if destination.is_dir():
                copy_destination = destination / source.name
            else:
                copy_destination = destination
            try:
                copyfile(source, copy_destination)
            except SameFileError as err:
                if not overwrite:
                    raise err
        else:
            if preserve_structure:
                # element is a directory. copy blank directory over
                if not destination.exists():
                    # Will not exist while preserving structure and iteratively
                    # creating the dir structure
                    destination.mkdir()
            # Pass the directory contents into "copy_or_link". Primarily
            # necessary for "copy_and_link" but adds small overhead to
            # "copy_data" which is a small cost for the flexibility of
            # these three programs.
            copy_or_link_data(list(source.iterdir()), destination,
                              preserve_structure=preserve_structure,
                              filesize_limit=filesize_limit,
                              overwrite=overwrite)


def symlink_data(source: Union[list, Path], destination: Union[Path, str],
                 preserve_structure=True, overwrite=False):
    """
This function takes a file, directory or list of files and/or
directories and creates a symlink of the files to target location (dir).
If the target directory doesn't exist, it fails. By default the flag
"preserve_structure" is set to True, which maintains the directory
structure of the source. If set to False, all files will be lumped
together in the destination. With lumping, there may be the possibility
of filename collision. By default, an optional overwrite flag is set to
False which will prevent file clobbering. If set to True, the files in
the destination folder will be overwritten.
    Parameters
    ----------
    source: Path, string or list of such objects
        object representing the location of the file(s)
        or the directory to be copied
    destination: Path or string
        Target directory
    preserve_structure: boolean (default=True)
        maintains the structure of the source directory. May be changed
        to False to lump files together. In this instance, use the
        "overwrite" flag to determine how to resolve name collisions
    overwrite: boolean (default=False)
        Optional flag for determining if the file or directory should be
        overwritten, if a file of the same name is found in the
        destination folder.

    **Calling Example**
    ::
        sample_file = Path("loc/text.txt")
        sample_directory = Path("loc")
        mixed_list = ["file1.txt",Path("file2.txt"), "dir1"]
        sample_output = Path("output")

        symlink_data(sample_file, sample_output)
        symlink_data(sample_directory, sample_output)
        symlink_data(mixed_list, sample_output)
    """
    # Raise TypeError if destination not Path or str
    # Convert to Path object for filehandling
    _instance_check([
        (destination, (Path, str)),
        (source, (Path, str, list))])
    destination = Path(destination)

    # Raise error if source is not string or Path object
    # convert to Path for filehandling
    if isinstance(source, str):
        source = Path(source)
    # A single DIRECTORY Path object is provided. Funnels to next if-statement
    if isinstance(source, Path) and source.is_dir():
        source = list(source.iterdir())

    # List is provided
    if isinstance(source, list):
        copy_or_link_data(source, destination,
                          preserve_structure=preserve_structure,
                          filesize_limit=.0001, overwrite=overwrite)

    # A single FILE Path object is provided
    else:
        # If either the source or destination path are not valid paths,
        # raise an Exception.
        if not source.exists():
            raise FileNotFoundError(f"Source {source} does not exist. "
                                    f"Program halting.")
        if not destination.parent.exists():
            raise NotADirectoryError(f"Destination parent {destination.parent} "
                                     f"does not exist. Program halting.")
        # If the source and the destination are the same, throw an Exception.
        # This is done to protect against unwanted file clobbering.
        if source.resolve() == destination.resolve():
            raise ValueError(f"Source {source} and destination {destination}"
                             f"are identical. Program halting.")
        # Only symlink the file if it doesn't exist OR overwrite flag is True
        if (destination / source.name).exists():
            # Resolve potential file clobbering based on flags
            if not overwrite:
                raise FileExistsError(f"""
"{(destination / source.name)}" already exists.
This may be due to "{source.name}" residing in separate directories
having the same name and preserve_structure flag being set to False
(which lumps all data being copied or symlinked together). The program
is halting here to prevent data loss in the new directory. If you
wish to proceed with overwriting, you may specify "overwrite=True'""")
            (destination / source.name).unlink()
        # Make the symlink
        if preserve_structure and destination.exists():
            # .resolve() expands to the absolute path
            (destination / source.name).symlink_to(source.resolve())
        elif preserve_structure:
            destination.symlink_to(source.resolve())
        else:
            (destination / source.name).symlink_to(source.resolve())
