#!/usr/bin/env python3
"""
Program name:       move_log_files.py

Date:               8 September, 2021

History:            First version

Authors:            Ramaswamy Tiruchirapalli, Edward Borders

Email:              ramaswamy.tiruchirapalli@noaa.gov, edward.borders@noaa.gov

Description:
    move_log_files: This function moves log files from a given source directory
    into destination directory.

    search_files:   This function searches files (recursively) with a
    specific pattern under a given directory.
    Recursive options can be turned on and off.

Modules/subroutines: logging, os, shutil, pathlib, typing
"""
import logging
import os
from pathlib import Path
import shutil
from typing import Union

# pylint: disable=too-many-branches
def move_log_files(source_dir: Union[str, Path],
                   dest_dir: Union[str, Path],
                   recursive: bool = False):
    """
    Move log files from source directory to destination.

    Parameters
    ----------
    source_dir: string or Path object
        source directory where log files are located
    dest_dir: string or Path object
        destination directory to be moved
    recursive: boolean (default=False)
        if True, log files are searched recursively (subdirectories
        are also searched)

    Returns
    -------
    None
    """

    # Check for validity of input parameters.
    if isinstance(source_dir, str):
        source_dir = Path(source_dir)
    if not isinstance(source_dir, Path):
        raise TypeError('source_dir should be a string or Path object')
    if isinstance(dest_dir, str):
        dest_dir = Path(dest_dir)
    if not isinstance(dest_dir, Path):
        raise TypeError('dest_dir should be a string or Path object')

    source_dir = source_dir.expanduser().resolve()
    dest_dir = dest_dir.expanduser().resolve()
    if not dest_dir.is_dir():
        raise NotADirectoryError(f'{dest_dir} is not a directory')
    if not source_dir.is_dir():
        raise NotADirectoryError(f'{source_dir} is not a directory')
    if not os.access(dest_dir, os.W_OK):
        raise PermissionError(f'${dest_dir} does not have write permissions')
    if source_dir.resolve() == dest_dir.resolve():
        raise shutil.SameFileError(
            'source and destination directories are the same'
        )

    if recursive:
        log_files = list(source_dir.rglob("*.log"))
    else:
        log_files = list(source_dir.glob("*.log"))
    if log_files:
        logging.debug(f'Moving log files to {dest_dir} :')
    else:
        logging.debug('No log files found')

    # move log files
    for log_file in log_files:
        try:
            shutil.move(str(log_file), dest_dir)
            logging.debug(f'{log_file} ')
        except:
            logging.error('Error in moving log files')
            raise
        if Path(log_file).exists():
            logging.error(f'The file was not moved : {log_file}')
