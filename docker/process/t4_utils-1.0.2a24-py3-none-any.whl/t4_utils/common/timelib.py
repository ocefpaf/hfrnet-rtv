"""
This module provides some commonly used functions and classes
related to date and time

"""

from datetime import datetime, timedelta, time
import logging
from typing import Union, Optional

# create logger
logger = logging.getLogger(__name__)


def get_datetime_min_time(date_time: datetime) -> datetime:
    """Returns min time of a given datetime

    For example:

    .. doctest ::

    >>> some_dt = datetime(2019, 6,10, 10,0,10)
    >>> get_datetime_min_time(some_dt)
    datetime.datetime(2019, 6, 10, 0, 0)

    Parameters
    ----------
    date_time : datetime

    """
    min_time = datetime.combine(date_time, time.min)

    return min_time


def get_seconds_since_epoch(date_time: datetime) -> float:
    return (date_time - datetime.utcfromtimestamp(0)).total_seconds()


class InvalidIntervalLimitsError(ValueError):
    pass


class TimeInterval:
    """Creates a closed time interval object
    """
    start: datetime
    end: datetime
    length: timedelta

    def __init__(self, start: datetime, end: Optional[datetime]=None, length=timedelta(0)):
        self.start = start
        if end:
            self.end = end
            self.length = end - start
        else:
            self.length = length
            self.end = self.start + self.length

        if self.end < self.start:
            raise InvalidIntervalLimitsError(
                f"End time of {self.end} is before given interval start time "
                f"{self.start}.")

    def has_time(self, input_time: datetime):
        """ Check to see if the time interval includes ``time``

        Parameters
        ----------
        input_time : datetime.datetime
        """
        return self.start <= input_time <= self.end

    def does_intersect(self, time_interval):
        """ Checks whether the input ``time_interval`` intersects with
        the object

        Parameters
        ----------
        time_interval : TimeInterval
        """
        result = (time_interval.end >= self.start) and \
                 (time_interval.start <= self.end)
        return result

    def get_intersect(self, time_interval: 'TimeInterval'):
        """ Calculate the intersection with another TimeInterval
        :param time_interval:
        :return:
        """
        if not self.does_intersect(time_interval):
            return None

        intersect_start = max(self.start, time_interval.start)
        intersect_end = min(self.end, time_interval.end)
        intersect_interval = TimeInterval(intersect_start, intersect_end)
        return intersect_interval

    def is_subset_of(self, time_interval):
        result = (self.start >= time_interval.start) and \
                 (self.end <= time_interval.end)
        return result

    def is_superset_of(self, time_interval):
        return time_interval.is_subset_of(self)

    def __str__(self):
        return str(self.start) + ' - ' + str(self.end)
