"""
This module creates a directory tree structure choice of permissions
Updated: Trevor Clack 30Mar2021
Update notes:
    19mar:fuller examples and clarity to docstrings
    30mar: removed creat_dir, added duplicate_tree_hook to
           create_dirs_from_tree to check for duplicates in user
           specified structure -- consequently, tree structure
           changed from dictionary to a "string of a dictionary"
    5apr: adjustments for PEP8
"""
from json import JSONDecoder
import os
import pathlib

def duplicate_tree_hook(pairs):
    """
    supporting function
    acts as a hook in a json string to check for duplicate entries
    specified by a user. Ideally the input will equal the output
    otherwise a KeyError is raised which is used in testing

    Input: dict
    The tree structure
    (passed implicitly, converted by json from string)

    Output: dict
    The same stree structure if KeyError is not raised
    """
    directories = dict()
    for key, val in pairs:
        if key in directories:
            raise KeyError("Duplicate key specified: %s" % key)
        directories[key] = val
    return directories

def create_dirs_from_tree(tree, parent='.', mode=0o755, check_for_duplicate=0):
    """
    Takes a dictionary and recursively creates file structure with
    specified permissions by calling 'create_dir'

    A note about umask: a umask (user mask) is a linux security feature
    which sets the default permissions for newly created files. This
    avoids default behavior like inadvertently allowing new files to be
    edited or sometimes writeable by the group or others. The mask sets
    the offset from full permissions. For example, umask(022) gives
    permissions of 777 - 022 = 755. In this function, in order for the
    intended mode to be properly created, the umask is temporarily set
    to 000 while pathlib creates the new directory. The default umask
    is reinstated immediately following the new directory creation.

    Parameters
    ------------

    tree: string of a dictionary
        key:    expects a string (dir_name)
                eg. 'src'

        value:  nested dictionary with string as key as explained above.
                Terminates with None or empty dictionary
                eg. { 'tests': {} }
                eg. None
                eg. {}

        full example of tree:
                DIR_TREE = '''{
                    "root_dir": {
                        "A": {
                            "1": {
                                "a": {}
                            },
                            "2": {
                                "a": {},
                                "b": {}
                            },
                            "3": {}
                        },
                        "B": {
                            "1": {}
                        }
                    }
                }
                '''

    parent: str
        Full or relative path where to begin directory tree build.
        Defaults to current working directory.
    mode: octal number
        Octal number representing permissions
        eg. for 755 -- 0o755
    check_for_duplicate: boolean, 0 or 1
        should be left alone. Intended to perform an initial
        check for duplicate keys in a tree. Example of such a tree:
            bad_tree = ```{
                    "test_dir": {
                        "A": {},
                        "B": {},
                        "A": {}
                        }
                    }
                    ```
    """
    if not check_for_duplicate:
        # On first pass, "stringed-dictionary" is checked for duplicates
        # If no duplicates exist, tree is passed on as a dictionary
        # and built to user specication
        decoder = JSONDecoder(object_pairs_hook=duplicate_tree_hook)
        tree = decoder.decode(tree)

    for dir_name, val in tree.items():
        out_path = os.path.join(parent, dir_name)
        default_umask = os.umask(0) # temporarily overwrite default umask
        pathlib.Path(out_path).mkdir(mode, parents=True, exist_ok=False)
        os.umask(default_umask) # reinstate default system mask
        if val:
            create_dirs_from_tree(val, out_path, mode, check_for_duplicate=1)
