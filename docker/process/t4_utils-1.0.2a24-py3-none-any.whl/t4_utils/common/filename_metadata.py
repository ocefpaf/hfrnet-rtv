"""
This module provides functions for extracting metadata from satellite file names
"""

from datetime import datetime, timedelta
from pathlib import Path
import re
from typing import Union

from t4_utils.common import configs as cfg


class PathFormatError(ValueError):
    pass


def _get_path_datetimes(strings: dict,
                        formats: dict) -> dict:
    """
    Helper function that takes dictionary of regex matched start/end/create
    strings and the datetime format needed to convert them into a datetime
    object to return a dictonary of datetime objects.

    Parameters
    ----------
    strings: dict
    Dictionary of strings that were determined via regex matching.

    formats: dict
    Dictionary of formats to be used to convert the regex matched strings to a
    datetime object.

    Returns
    -------
    Dictionary that holds the datetime objects for start/end/create times. If
    one of those string aren't available for conversion to a datetime object
    None will be returned instead.

    """
    datetime_objects_dict = _convert_strings_to_datetimes(strings, formats)

    _combine_date_times(datetime_objects_dict)

    # Return start, end and create datetimes (set to None if unavailable)
    required_keys = cfg.METADATA_KEYS['dates']
    return {k: datetime_objects_dict.get(k, None) for k in required_keys}


def _ensure_correct_datetime_conversion(datetime_object: datetime,
                                        string: str, str_format: str):
    """
    Converts the datetime object back to a filename string.
    Determines if the converted datetime objects matches the original filename.

    Parameters
    ----------
    datetime_object: datetime
    Datetime object created from the filename and format.

    string: str
    String that was determined via regex matching.

    str_format: str
    String format used to convert the datetime object into a string

    Returns
    -------
    None or False

    """

    string_datetime = datetime_object.strftime(str_format)

    # Accounts for files that have fake microseconds aka mostly zeros and should
    # be removed from the datetime object string
    if len(string) != 20 and str(datetime_object.microsecond)[1:] == '00000':
        string_datetime = string_datetime[:-5]
    elif '%f' in str_format and '.' not in str(datetime_object):
        string_datetime = string_datetime[:-5]

    if string_datetime != string:
        return True
    return None


def _convert_strings_to_datetimes(strings: dict, formats: dict) -> dict:
    """
    Converts start/end/create strings grabbed from filenames to datetime
    objects. Uses the configurations set in configs.py to determine the
    datetime string format that needs to be passed to the datetime function.

    Parameters
    ----------
    strings: dict
    Dictionary of strings that were determined via regex matching.

    formats: dict
    Dictionary of formats to be used to convert the regex matched strings to a
    datetime object.

    Returns
    -------
    Dictionary that holds datetime objects for start/end/create times.
    """

    # Make sure the keys match (not sure if I should check this, since this is
    # a private function...
    if set(strings.keys()) != set(formats.keys()):
        raise ValueError("Keys of 'strings' and 'formats' dictionaries are"
                         f"different ([{','.join(strings.keys())}] "
                         f"vs [{','.join(formats.keys())})]")
    # Get all available datetime objects from their corresponding strings
    path_dts = {}
    for key in strings:
        try:
            path_dts[key] = datetime.strptime(strings[key], formats[key])
        except ValueError as exp:
            raise PathFormatError(f"Invalid date string. Cannot convert {key}'s"
                                  f'string "{strings[key]}" to datetime object '
                                  f'using format "{formats[key]}"') from exp

        if _ensure_correct_datetime_conversion(path_dts[key], strings[key],
                                               formats[key]):
            raise ValueError(
                "Datetime object does not match original filename.")
    return path_dts


def _combine_date_times(datetime_objects_dict: dict):
    """
    Combines separate date and time objects into a single object. This function
    accounts for filenames that have separate strings for date and
    start/end/create times. This will modify the datetime_objects_dict input in
    place.

    Parameters
    ----------
    datetime_objects_dict: dict

    Dictionary that holds initial datetime objects created from the filename
    string.
    """

    # Some file naming conventions, have a date and start/end time(s)
    date_key = 'date'
    for time_key in ['start_time', 'end_time']:
        if {time_key, date_key} <= datetime_objects_dict.keys():
            datetime_objects_dict[time_key[:-5]] = datetime.combine(
                datetime_objects_dict[date_key].date(),
                datetime_objects_dict[time_key].time())
    # Correct end datetime if earlier than start datetime
    if datetime_objects_dict.get('end', datetime.max) < \
            datetime_objects_dict.get('start', datetime.min):
        datetime_objects_dict['end'] += timedelta(days=1)


def extract_path_info(path: Union[Path, str]):
    """
    This function will scrape the date and time from a file and return a
    dictionary that holds datetime objects for the  start, end, and create (if
    available) date/time.

    Parameters
    ----------
    path : Path, str
        A relative or absolute path to a file that contains date/time
        information to be collected.

    Returns
    -------
    dict
        Dictionary with start, end, and create keys that hold datetime objects
        if available and None if no datetime objects are available.

    """
    path = Path(path)
    file_name = path.name

    for file_type_config_dict in cfg.DATA_PATTERNS.values():
        reg_pattern = str(file_type_config_dict["regex_pattern"])
        datetime_formats_dict: dict = file_type_config_dict["datetime_formats"]
        match_dict = None
        match = re.match(reg_pattern, file_name)
        if match:
            match_dict = match.groupdict()
        if match_dict is None:
           continue
        return _get_path_datetimes(match_dict, datetime_formats_dict)

    # Should have found a match by now
    raise NotImplementedError(f"Cannot find a match for {file_name}")


def fix_filename_timestamp(filepath: Union[Path, str]):
    """
    Accurately adjusts any generic filename (with s,e,c times) to be
    under 599 seconds within the timestamp.

    Parameters
    ----------
    filepath: Path, str
        A relative or absolute filepath that contains date/time
        information to be collected.

    Returns
    -------
    str
        Final edited filepath to be used, with correctly wrapped
        seconds in the filename.
    """
    input_filepath = Path(filepath)
    filename = input_filepath.name
    file_dir = input_filepath.parent

    # Determine if the filename is given as Julian or MMDD format.
    julian_match = re.search(r'_s(\d{14})_e(\d{14})_c(\d{11})(\d{3})', filename)
    md_match = re.search(r'_s(\d{15})_e(\d{15})_c(\d{12})(\d{3})', filename)

    if julian_match:
        # Wrap SSS if beyond 599, then add to the original creation datetime.
        seconds_dt = timedelta(microseconds=int(julian_match.group(4)) * 1e5)
        c_time = datetime.strptime(julian_match.group(3), '%Y%j%H%M') + seconds_dt
        # The start and end times should remain unchanged.
        s_str = julian_match.group(1)
        e_str = julian_match.group(2)
        old_c_str = julian_match.group(3) + julian_match.group(4)
        new_c_str = c_time.strftime('%Y%j%H%M%S%f')[:-5]
    elif md_match:
        # Wrap SSS if beyond 599, then add to the original creation datetime.
        seconds_dt = timedelta(microseconds=int(md_match.group(4)) * 1e5)
        c_time = datetime.strptime(md_match.group(3), '%Y%m%d%H%M') + seconds_dt
        # The start and end times should remain unchanged.
        s_str = md_match.group(1)
        e_str = md_match.group(2)
        old_c_str = md_match.group(3) + md_match.group(4)
        new_c_str = c_time.strftime('%Y%m%d%H%M%S%f')[:-5]
    else:
        # If neither format is found, return the original filepath.
        return filepath

    output_filename = filename.replace(f'_s{s_str}_e{e_str}_c{old_c_str}',
                           f'_s{s_str}_e{e_str}_c{new_c_str}')
    output_filepath = file_dir / output_filename

    # Return the type that was provided
    if isinstance(filepath, str):
        return str(output_filepath)
    return output_filepath
