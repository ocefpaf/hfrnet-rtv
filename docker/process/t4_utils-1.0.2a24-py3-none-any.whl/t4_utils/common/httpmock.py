""" HTTPMock
Author:     Perry Bunn
Email:      perry.bunn@noaa.gov
Description:
    HTTPMock, mocks HTTP request from the Request library. This enables testing
    of request methods without making real api request. The HTTPMock class is
    suppose to emulate the Request.Response class. Some of the basic methods
    have been provided but since each delivery can be different in what the
    response should contain I have omitted the more complicated methods to allow
    developers to add them per project.

Resources:
----------
https://2.python-requests.org/en/master/user/advanced/#id2
https://docs.pytest.org/en/6.2.x/monkeypatch.html

Examples:
--------

Example 1: Pytest Fixture

... @pytest.fixture()
... def mock_response(self, monkeypatch):
...     def mock_post(*args, **kwargs):
...         return HTTPMock("test_url", 403, "Failed to post.")

    This line below is what is doing the grunt work, effectively we are
      replacing the post method from the request library and returning the
      HTTPMock class. If you would like to know more I have linked monkeypatch
      in the resources section of the module docstring.

...     monkeypatch.setattr(requests, "post", mock_post)
...
... def test_post_403_exception(self, mock_response):
...     res = requests.post("localhost:300", {"test_key": "test_data"})
...     assert res.status_code == 403

"""
from typing import Optional

from requests.exceptions import HTTPError

# Status code descriptions per RFC 2616, omitted codes 100-199, 201-399
codes = {
    200: "OK",
    400: "Bad Request",
    401: "Unauthorized",
    402: "Payment Required",
    403: "Forbidden",
    404: "Not Found",
    405: "Method Not Allowed",
    406: "Not Acceptable",
    407: "Proxy Authentication Required",
    408: "Request Timeout",
    409: "Conflict",
    410: "Gone",
    411: "Length Required",
    412: "Precondition Failed",
    413: "Payload Too Large",
    414: "URI Too Long",
    415: "Unsupported Media Type",
    416: "Range Not Satisfiable",
    417: "Expectation Failed",
    # Yes this is a real response status code,
    # https://datatracker.ietf.org/doc/html/rfc7168#section-2.3.3
    418: "I'm a teapot",
    421: "Misdirected Request",
    422: "Unprocessable Entity",
    423: "Locked",
    425: "Too Early",
    426: "Upgrade Required",
    428: "Precondition Required",
    429: "Too Many Requests",
    431: "Request Header Fields Too Large",
    451: "Unavailable For Legal Reasons",
    500: "Internal Server Error",
    501: "Not Implemented",
    502: "Bad Gateway",
    503: "Service Unavailable",
    504: "Gateway Timeout",
    505: "HTTP Version Not Supported",
    506: "Variant Also Negotiates",
    507: "Insufficient Storage",
    508: "Loop Detected",
    510: "Not Extended",
    511: "Network Authentication Required"
}


class HTTPMock:
    """
    Parameters:
    ----------
    url: str
        Default value is an empty string. Used if your code/test check the URL
        of the response
    status: int
        Status code of the response. Descriptors for status are only included
        for 200 and 400-599 in codes dictionary
    text: str = ""
        Message of the response. Used if you are validating response messages.
        Different from the generic RFC status descriptor which can be found in
        the codes dictionary. Default message is an empty string.
    json: dict = None
        JSON object of the response. Used if you need to validate a specific
        response from a endpoint. If this is left as None then the default
        object will be returned: {"mock_key": "mock_response"}
    """

    def __init__(self, url: str, status: int, text: str, json: Optional[dict]=None):
        # NOTE: This is done because dicts are mutable arguments. This avoids
        # any possibly of the dict being modified during init.
        if json is None:
            json = {"mock_key": "mock_response"}

        try:
            self.reason = codes[status]
        except KeyError:
            self.reason = f"INVALID STATUS CODE: {status}"

        # NOTE: The class attr, _json, is protected because if it were not it
        # would collide with the json() method. This is the same case for the
        # _text attr. This could be avoided by changing the methods to get_* but
        # I did this to more closely emulate the Request.Response class.
        self._json = json
        self._text = text
        self.status_code = status
        self.url = url

    def text(self):
        return self._text

    def json(self) -> dict:
        return self._json

    def get_status(self):
        return self.status_code

    def raise_for_status(self):
        """Raises :class:`HTTPError`, if one occurred."""
        err_msg = ''
        # Ignore status codes that are 100-399
        if 400 <= self.status_code < 500:
            reason = codes[self.status_code]
            err_msg = f"{self.status_code} Client Error: {reason} for url: " \
                      f"{self.url}"

        elif 500 <= self.status_code < 600:
            reason = codes[self.status_code]
            err_msg = f"{self.status_code} Server Error: {reason} for url: " \
                      f"{self.url}"

        if err_msg:
            raise HTTPError(err_msg, response=self)
