"""
This keeps the configurations needed for various utility modules
"""

METADATA_KEYS = {
    'dates': ['start', 'end', 'create']
}

# filename_metadata configs
DATA_PATTERNS = {
    'ABI_L1b': {
        'regex_pattern':
            r'OR_ABI-L\d{1}[a-z]{0,1}-Rad(F|C|M)-M\dC\d{2}_G\d{2}'
            r'_s(?P<start>\d{14})'
            r'_e(?P<end>\d{14})'
            r'_c(?P<create>\d{14}).nc',
        'datetime_formats':
            {'start': '%Y%j%H%M%S%f',
             'end': '%Y%j%H%M%S%f',
             'create': '%Y%j%H%M%S%f'}
    },
    'AMSR2': {
        'regex_pattern':
            r'AMSR2-(OCEAN|PRECIP|MBT)_v\d{1,2}r\d{1,2}_GW1'
            r'_s(?P<start>\d{15})'
            r'_e(?P<end>\d{15})'
            r'_c(?P<create>\d{15}).nc',
        'datetime_formats':
            {'start': '%Y%m%d%H%M%S%f',
             'end': '%Y%m%d%H%M%S%f',
             'create': '%Y%m%d%H%M%S%f'}
    },
    'GMI': {
        'regex_pattern':
            r'1C-R.GPM.GMI.XCAL2016'
            r'-C.(?P<date>\d{8})'
            r'-S(?P<start_time>\d{6})'
            r'-E(?P<end_time>\d{6})'
            r'.V\d{2}[A-Z].RT-H5',
        'datetime_formats':
            {'date': '%Y%m%d',
             'start_time': '%H%M%S',
             'end_time': '%H%M%S'}
    },
    'ABI_AHI_L2_FW2': {
        'regex_pattern':
            r'(GOES\d{2}|Himawari\d)_A(B|H)I_(\dKM|\d{3}M)_(FD|CONUS|MESO|FLDK)'
            r'_(?P<start>\d{7}_\d{4}_\d{2})'
            r'_(CLOUD_MASK|CLOUD_PHASE|CLOUD_HEIGHT|AEROSOL_AOD'
            r'|AEROSOL_ADP|RADBUD_SRB|RADBUD_OLR|CLOUD_DCOMP|CLOUD_NCOMP'
            r'|LAND_LST|CRYOS_ICE_CONC|LAND_SFC_ALBEDO|LAND_FIRE|FD_NAV)'
            r'(_EN|_BL|)(-Snow|-Mode_8|).(nc|NC)',
        'datetime_formats':
            {'start': '%Y%j_%H%M_%S'}
    },
    'ABI_AHI_L2_FW1': {
        'regex_pattern':
            r'(GOESR|Himawari)_A(B|H)I_(FD|CONUS|MESO|FLDK)'
            r'_(?P<start>\d{7}_\d{4}_\d{2})'
            r'_(CLOUD_MASK|CLOUD_PHASE|CLOUD_HEIGHT|AEROSOL_AOD'
            r'|AEROSOL_ADP|RADBUD_SRB|RADBUD_OLR|CLOUD_DCOMP|CLOUD_NCOMP'
            r'|LAND_LST|CRYOS_ICE_CONC|LAND_SFC_ALBEDO|LAND_FIRE|FD_NAV)'
            r'(_EN|_BL|)(-Snow|-Mode_8|).(nc|NC)',
        'datetime_formats':
            {'start': '%Y%j_%H%M_%S'}
    },
    'ABI_L2_NDE': {
        'regex_pattern':
            r'OR-ABI-L\d-CSRF-M\d_v\dr\d_G\d{2}'
            r'_s(?P<start>\d{15})'
            r'_e(?P<end>\d{15})'
            r'_c(?P<create>\d{15})'
            r'.nc',
        'datetime_formats':
            {'start': '%Y%m%d%H%M%S%f',
             'end': '%Y%m%d%H%M%S%f',
             'create': '%Y%m%d%H%M%S%f'}
    },
    'ABI_DMW': {
        'regex_pattern':
            r'OR_ABI-L2-'
            r'DMW(F|PQIF|DIAGF|VF|VPQIF|VDIAGF|C|PQIC|DIAGC|VC|VPQIFC|VDIAGC)'
            r'-M\dC\d{2}_G\d{2}'
            r'_s(?P<start>\d{14})'
            r'_e(?P<end>\d{14})'
            r'_c(?P<create>\d{14})'
            r'.nc',
        'datetime_formats':
            {'start': '%Y%j%H%M%S%f',
             'end': '%Y%j%H%M%S%f',
             'create': '%Y%j%H%M%S%f'}
    },
    'ABI_FLS': {
        'regex_pattern':
            r'ABI-L2-GFLS(F|C)(-AWIPS|)-M6_v\dr\d_g\d{2}'
            r'_s(?P<start>\d{15})'
            r'_e(?P<end>\d{15})'
            r'_c(?P<create>\d{15})'
            r'.nc',
        'datetime_formats':
            {'start': '%Y%m%d%H%M%S%f',
             'end': '%Y%m%d%H%M%S%f',
             'create': '%Y%m%d%H%M%S%f'}
    },
    'ABI_FLS_Intermediate': {
        'regex_pattern':
            r'G\d{2}_FLS_(FD|CONUS)_IntermediateData'
            r'_(?P<start>\d{14})'
            r'.tar',
        'datetime_formats':
            {'start': '%Y%j%H%M%S%f'}
    },
    'ABI_AHI_AMV_FW2': {
        'regex_pattern':
            r'(GOES\d{2}|Himawari\d)_A(B|H)I_(\dKM|\d{3}M)_(FD|CONUS|MESO|FLDK)'
            r'_(?P<start>\d{7}_\d{4}_\d{2})'
            r'_WINDS_AMV_(EN|BL)-\d{2}-[A-Z]{2}'
            r'.(nc|md|bufr|bufrT)',
        'datetime_formats':
            {'start': '%Y%j_%H%M_%S'}
    },
    'ABI_AHI_AMV_FW1': {
        'regex_pattern':
            r'(GOESR|Himawari)_A(B|H)I_(FD|CONUS|MESO|FLDK)'
            r'_(?P<start>\d{7}_\d{4}_\d{2})'
            r'_WINDS_AMV_(EN|BL)_CH\d{2}(_[A-Z]{2}|)'
            r'.(nc|md|bufr|bufrT)',
        'datetime_formats':
            {'start': '%Y%j_%H%M_%S'}
    },
    'ABI_DMW_BUFR': {
        'regex_pattern':
            r'DMW(VF|F|VC|C)-M\dC\d{2}_v\dr\d_g\d{2}'
            r'_s(?P<start>\d{15})'
            r'_e(?P<end>\d{15})'
            r'_c(?P<create>\d{15})'
            r'.bufr',
        'datetime_formats':
            {'start': '%Y%m%d%H%M%S%f',
             'end': '%Y%m%d%H%M%S%f',
             'create': '%Y%m%d%H%M%S%f'}
    },
    'BlendedRainRateTPW_NetCDF': {
        'regex_pattern':
            r'BHP-(PCT|RR)_v*\d*r\d_blend'
            r'_s(?P<start>\d{15})'
            r'_e(?P<end>\d{15})'
            r'_c(?P<create>\d{15})'
            r'.nc',
        'datetime_formats':
            {'start': '%Y%m%d%H%M%S%f',
             'end': '%Y%m%d%H%M%S%f',
             'create': '%Y%m%d%H%M%S%f'}
    },
    'NUCAPS': {
        'regex_pattern':
            r'NUCAPS-([A-Z]{3}|[A-Z]\d{4})(-[A-Z]{2}|)_v\dr\d_j01'
            r'_s(?P<start>\d{15})'
            r'_e(?P<end>\d{15})'
            r'_c(?P<create>\d{15})'
            r'.(nc|bufr)',
        'datetime_formats':
            {'start': '%Y%m%d%H%M%S%f',
             'end': '%Y%m%d%H%M%S%f',
             'create': '%Y%m%d%H%M%S%f'}
    },
    'NUCPAS_Binary': {
        'regex_pattern':
            r'(atms|cris)'
            r'_(?P<date>\d{8})'
            r'_(?P<start_time>\d{7})'
            r'_(?P<end_time>\d{7})'
            r'.binary',
        'datetime_formats':
            {'date': '%Y%m%d',
             'start_time': '%H%M%S%f',
             'end_time': '%H%M%S%f'}
    },
    'VIIRS_L2_NDE': {
        'regex_pattern':
            r'(JRR-|SURFALB|LST)'
            r'(ADP|AOD|VolcanicAsh|CloudBase|CloudDCOMP|CloudNCOMP'
            r'|CloudCoverLayers|CloudHeight|CloudMask|CloudPhase|IceAge'
            r'|IceConcentration|SnowCover|)'
            r'_v\dr\d_(npp|j01|n21)'
            r'_s(?P<start>\d{15})'
            r'_e(?P<end>\d{15})'
            r'_c(?P<create>\d{15})'
            r'.nc',
        'datetime_formats':
            {'start': '%Y%m%d%H%M%S%f',
             'end': '%Y%m%d%H%M%S%f',
             'create': '%Y%m%d%H%M%S%f'}
    },
    'ABI LSA Spinup': {
        'regex_pattern':
            r'TOADB'
            r'_(?P<start>\d{7}_\d{4})'
            r'.bin',
        'datetime_formats':
            {'start': '%Y%j_%H%M'}
    },
    'ABI Offline LSA': {
        'regex_pattern':
            r'brdfprm'
            r'_(?P<start>\d{7})'
            r'.nc',
        'datetime_formats':
            {'start': '%Y%j'}
    },
    'ABI L1B FW1': {
        'regex_pattern':
            r'GOESR_ABI_(FD|CONUS|MESO)'
            r'_(?P<start>\d{7}_\d{4}_\d{2})'
            r'_SAT_ABI_L1B_Band\d{2}_(\dKM|\d{3}M)'
            r'.nc',
        'datetime_formats':
            {'start': '%Y%j_%H%M_%S'}
    },
    'ABI NAV FW1': {
        'regex_pattern':
            r'GOESR_ABI_(FD|CONUS|MESO)'
            r'_(?P<start>\d{7}_\d{4}_\d{2})'
            r'_SAT_ABI_NAV_(\dKM|\d{3}M)'
            r'.nc',
        'datetime_formats':
            {'start': '%Y%j_%H%M_%S'}
    },
    'AHI L1b': {
        'regex_pattern':
            r'HS_H\d{2}'
            r'_(?P<start>\d{8}_\d{4})'
            r'_B\d{2}_FLDK_R\d{2}_S\d{4}'
            r'.DAT(.bz2|)',
        'datetime_formats':
            {'start': '%Y%m%d_%H%M'}
    },
    'PMW Match': {
        'regex_pattern':
            r'PMW_JM(ABI|AHI)'
            r'_(?P<start>\d{14})'
            r'.nc',
        'datetime_formats':
            {'start': '%Y%j%H%M%S%f'}
    },
    'Train Regression': {
        'regex_pattern':
            r'regressA'
            r'(?P<start>\d{10})'
            r'.nc',
        'datetime_formats':
            {'start': '%Y%m%d%H'}
    },
    'AVHRR L1b': {
        'regex_pattern':
            r'NSS.(FRAC|GHRR|HRPT).(M1|M3)'
            r'.D(?P<date>\d{5})'
            r'.S(?P<start_time>\d{4})'
            r'.E(?P<end_time>\d{4})'
            r'.B\d{7}'
            r'.(SV|MM|WI|MO|GC|CF|DU|EB|HO|MM|SF|SN|SO|WE)',
        'datetime_formats':
            {'date': '%y%j',
             'start_time': '%H%M',
             'end_time': '%H%M'}
    },
    'BlendedHydro_Composite_HDF': {
        'regex_pattern':
            r'(?P<start>\d{13})'
            r'_(BLENDED_RR(_MEAN|)|TPW)_COMPOSITE'
            r'.HDF',
        'datetime_formats':
            {'start': '%Y%j%H%M%S'}
    },
    'BlendedHydro HDF': {
        'regex_pattern':
            r'(?P<start>\d{13})'
            r'_(GPMW|NOAA\d{2}|DMSP\d{2}|METOP(A|B)|NPP|GCOMW)'
            r'_(AMSR2|MIRS)_(IMG_(AMSU|ATMS|GMI)|PRECIP|OCEAN)'
            r'(_(RR|TPW)_CORRECTION_REMAP|)'
            r'.HDF',
        'datetime_formats':
            {'start': '%Y%j%H%M%S'}
    },
    'BlendedHydro McIDAS': {
        'regex_pattern':
            r'(?P<start>\d{13})'
            r'_(BLENDED_RR|TPW)_COMPOSITE(_SMOOTH(_PCT|_GPS|)|)'
            r'.mcAREA',
        'datetime_formats':
            {'start': '%Y%j%H%M%S'}
    },
    'BlendedHydro ASCII': {
        'regex_pattern':
            r'(?P<start>\d{13})'
            r'_(CORR_RR|TPW_PENTAD)_STATS'
            r'_(MIRS_(NPP\d|NOAA\d{2}|METOP\d|DMSP\d{2}|GPM\d)|GCOMW1)'
            r'.TXT',
        'datetime_formats':
            {'start': '%Y%j%H%M%S'}
    },
    'GPS-PMV': { # Needs logic added to script. NOT CURENTLY WORKING
        'regex_pattern':
            r'(?P<start>\d{6}).gps',
        'datetime_formats':
            {'start': '%D%H%M'}
    },
    'NRL Winds': {
        'regex_pattern':
            r'(IR|VIS|WV)_winds_\d{3}mb_\d{3}mb_(?P<start>\d{8})',
        'datetime_formats':
            {'start': '%Y%m%d'}
    },
    'MIRS': {
        'regex_pattern':
            r'NPR-MIRS-(IMG(_33min|)|SND)_v*\d*(r\d|)'
            r'_(ma\d|gpm|n\d{2}|f\d{2}|npp)'
            r'_s(?P<start>\d{15})'
            r'_e(?P<end>\d{15})'
            r'_c(?P<create>\d{15})'
            r'.nc',
        'datetime_formats':
            {'start': '%Y%m%d%H%M%S%f',
             'end': '%Y%m%d%H%M%S%f',
             'create': '%Y%m%d%H%M%S%f'}
    },
    'HISA Input-ADECK': {
        'regex_pattern':
            r'(?P<start>\d{14})'
            r'-a(wp|sh|io|al|ep|cp)\d{6}'
            r'.dat',
        'datetime_formats':
            {'start': '%Y%m%d%H%M%S'}
    },
    'MWCOMB': {
        'regex_pattern':
            r'ssmi-comb-snnm-anal'
            r'-(?P<start>\d{10})',
        'datetime_formats':
            {'start': '%Y%m%d%H'}
    },
    'SAT_VIIRS output': {
        'regex_pattern':
            r'SAT_VIIRS_(J01|NPP)_(NAV|L1B_Band\d{2})_\d{3}M'
            r'_s(?P<start>\d{15})'
            r'_e(?P<end>\d{15})'
            r'_c(?P<create>\d{15})'
            r'.nc',
        'datetime_formats':
            {'start': '%Y%m%d%H%M%S%f',
             'end': '%Y%m%d%H%M%S%f',
             'create': '%Y%m%d%H%M%S%f'}
    },
    'VIIRS Land Mask': {
        'regex_pattern':
            r'LAND_MASK_(J01|NPP)'
            r'_s(?P<start>\d{15})'
            r'_e(?P<end>\d{15})'
            r'_c(?P<create>\d{15})'
            r'.nc',
        'datetime_formats':
            {'start': '%Y%m%d%H%M%S%f',
             'end': '%Y%m%d%H%M%S%f',
             'create': '%Y%m%d%H%M%S%f'}
    },
    'VIIRS LSA filtered tile': {
        'regex_pattern':
            r'(NOAA\d{2}|NPP)_VIIRS_LSA_'
            r'h\d{2}v\d{2}_(?P<start>\d{7})'
            r'_FLT.nc',
        'datetime_formats':
            {'start': '%Y%j'}
    },
    'VIIRS LSA': {
        'regex_pattern':
            r'(NOAA\d{2}|NPP)_VIIRS_LSA'
            r'_(?P<start>\d{7})_h\d{2}v\d{2}'
            r'.nc',
        'datetime_formats':
            {'start': '%Y%j'}
    },
    # used in some NRT processing
    'VIIRS granule ID': {
        'regex_pattern':
            r'(j\d{2}|npp|n21)'
            r'_d(?P<date>\d{8})'
            r'_t(?P<start_time>\d{7})'
            r'_e(?P<end_time>\d{7})'
            r'_b\d{5}([A-Z]|)',
        'datetime_formats':
            {'date': '%Y%m%d',
             'start_time': '%H%M%S%f',
             'end_time': '%H%M%S%f'}
    },
    'MSG': {
        'regex_pattern':
            r'H-\d{3}-MSG\d*_*-MSG\d'
            r'(_IODC|)*_*-(IR_\d{3}|VIS\d{3}|)*_*'
            r'-(\d{6}|PRO)*_*'
            r'-(?P<start>\d{12})'
            r'-(C|)*_*',
        'datetime_formats':
            {'start': '%Y%m%d%H%M'}
    },
    'VIIRS L1B': {
        'regex_pattern':
            r'(G(I|M)TCO|SV(M|I)\d{2})_(j01|npp|j02)'
            r'_d(?P<date>\d{8})'
            r'_t(?P<start_time>\d{7})'
            r'_e(?P<end_time>\d{7})'
            r'_b\d{5}'
            r'_c(?P<create>\d{20})'
            r'_([A-Za-z_]+)'
            r'\.(h5|nc)',
        'datetime_formats':
            {'date': '%Y%m%d',
             'start_time': '%H%M%S%f',
             'end_time': '%H%M%S%f',
             'create': '%Y%m%d%H%M%S%f'}
    },
    'HISA Products': {
        'regex_pattern':
            r'TC-[a-z]{2}\d{6}-XYA_v\dr\d_(npp|metop(a|b)|noaa\d{2})'
            r'_s(?P<start>\d{15})'
            r'_e(?P<end>\d{15})'
            r'_c(?P<create>\d{15})'
            r'.nc',
        'datetime_formats':
            {'start': '%Y%m%d%H%M%S%f',
             'end': '%Y%m%d%H%M%S%f',
             'create': '%Y%m%d%H%M%S%f'}
    },
    # this may be unused at this point
    'VPW Remap': {
        'regex_pattern':
            r'(s|n)ps_VIIRS_(NPP|J\d{2}|N\d{2})'
            r'_(?P<start>\d{7}_\d{4}_\d{2})'
            r'_ALL_\d{4}_\d{4}_v\d{1}r\d{1}.nc',
        'datetime_formats':
            {'start': '%Y%j_%H%M_%S'}
    },
    'VPW Remap v2': {
        'regex_pattern':
            r'(s|n)ps_(NPP|NOAA\d{2})_VIIRS_\d{3}M_Granule_\d{4}x\d{4}'
            r'_(?P<start>\d{7}_\d{4}_\d{2}).nc',
        'datetime_formats':
            {'start': '%Y%j_%H%M_%S'}
    },
    'VPW Winds': {
        'regex_pattern':
            r'PAMV-VIIRS-CD-(N|S)H_v\dr\d_(npp|j01|n21)'
            r'_s(?P<start>\d{15})'
            r'_e(?P<end>\d{15})'
            r'_c(?P<create>\d{15})'
            r'.nc',
        'datetime_formats':
            {'start': '%Y%m%d%H%M%S%f',
             'end': '%Y%m%d%H%M%S%f',
             'create': '%Y%m%d%H%M%S%f'}
    },
    'VPW Remap image timestamp': {
        'regex_pattern':
            r'(npp|j01|n21)_(?P<start>\d{7}_\d{4}_\d{2})',
        'datetime_formats':
            {'start': '%Y%j_%H%M_%S'}
    }
}
