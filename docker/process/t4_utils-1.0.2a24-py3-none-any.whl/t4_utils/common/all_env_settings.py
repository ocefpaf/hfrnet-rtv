"""
This module provides functions for setting up a list of processing environment variables
"""

from .env_settings import set_env_var


def set_all_env_var(env_vars: dict):

    """
    This function sets the environment variables by looping
    through the items provided by the input dict

    Parameters
    ==========
    env_vars: dict\n
        A dictionary containing pairs of (key: value)
        Where:
            key:
            Name of the environment variable to be set\n
            Check the function set_env_var() to see the type allowed\n

            value:
            Value of the environment variable to be set.\n
            Check the function set_env_var() to see the type allowed\n

    Example
    -------
        sample_list = {
                        "ENV_AAAAA": 111,
                        "ENV_BBBBB": 222.0,
                        "ENV_CCCCC": Path("/foo/333"),
                        "ENV_DDDDD": "DDDD",
                      }
        set_all_env_var(sample_list)
    """
    if not isinstance(env_vars, dict):
        raise TypeError("Input should be a dict")

    for key, value in env_vars.items():
        set_env_var(key, value)
