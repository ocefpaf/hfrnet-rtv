"""
This module provides a decorator for wrapping arbitrary functions in
try/except blocks with an associated logger.
"""
import sys
import logging
from inspect import isclass
from functools import wraps


def try_except(exceptions, logger=logging.getLogger(), level=logging.INFO):
    """
    The try_except function acts as a decorator for arbitrary functions.

    If the logger is already initialized when the function is defined,
    it can be used with @ syntax. eg:

    @try_except(exceptions [, logger [, level]])
    def func(<args>):
        ...

    Otherwise the function needs to be wrapped at runtime. eg:

    try_except(exceptions [, logger [, level]])(func)(<args>)

    Parameters
    ----------
    exceptions : tuple of BaseExceptions
    The classes of exceptions to catch.

    logger : Logger
    The logger to report to.
    logging.getLogger() (root logger) by default

    level : int
    The level by which to log function starting and stopping.
    logging.INFO (20) by default
    """

    if not isinstance(exceptions, tuple):
        raise TypeError(f'{exceptions} is not a tuple')
    for exp in exceptions:
        if not isclass(exp):
            raise TypeError(f'{exp} is not a class')
        if not issubclass(exp, BaseException):
            raise TypeError(f'{exp} is not of BaseException')
    if not isinstance(logger, logging.Logger):
        raise TypeError(f'{logger} is not a logging.Logger')
    if not isinstance(level, int):
        raise TypeError(f'{level} is not an int value')

    def wrapper(func):
        if not callable(func):
            raise TypeError(f'{func} not callable ')

        @wraps(func)
        def wrapped_func(*args, **kwargs):
            name = func.__name__
            try:
                logger.log(level, f'{name} starting')
                func_output = func(*args, **kwargs)
                logger.log(level, f'{name} finished successfully')
                return func_output
            except exceptions as exp:
                logger.exception(f'There was an error "{exp}" '
                                 f'running {name}')
                sys.exit(1)
        return wrapped_func
    return wrapper
