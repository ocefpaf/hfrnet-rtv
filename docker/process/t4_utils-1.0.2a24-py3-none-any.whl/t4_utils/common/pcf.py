"""
The common_utils.pcf module provides functions for reading to and
writing from PCFs.

read_pcf allows the user to convert a PCF at the specified path to a
dictionary.

write_pcf allows the user to convert a dictionary to a PCF at the
specified path.
"""
import re
from pathlib import Path, PosixPath


def _blank_line(line):
    stripped_line = line.lstrip()
    return len(stripped_line) == 0 or stripped_line[0] == '#'


def _valid_key(key):
    return not bool(re.compile('[^a-zA-Z0-9_\\-]').search(key))


#pylint: disable=too-many-branches,too-many-statements
def read_pcf(pcf_path_param, header=None, footer=None, pass_bad=False,
             empty_val=False):
    """
    Reads the PCF at the path specified and returns a corresponding
    dictionary, providing formatting exceptions with additional
    parameters. Blank lines and lines that begin with '#' will be
    ignored. If a header is specified, the PCF will not be read
    until after the header is encountered. If a footer is specified,
    The PCF will stop being read once the footer is encountered.

    Parameters
    ----------
    pcf_path_param : str or pathlib.PosixPath
    The path to the existing PCF to be read

    header : str
    If specified, the PCF will not be read until the header is met

    footer : str
    If specified, the PCF will stop reading once the footer is met

    pass_bad : bool
    If False, a ValueError will be thrown if an invalid line is
    encountered in the PCF. Otherwise the line will be passed over.

    empty_val : bool
    If False, a ValueError will be thrown if an empty value is encountered
    in the PCF. Otherwise the the value will be assigned to ""
    """
    if isinstance(pcf_path_param, str):
        pcf_path = Path(pcf_path_param)
    elif isinstance(pcf_path_param, PosixPath):
        pcf_path = pcf_path_param
    else:
        raise TypeError(f'pcf_path_param:{pcf_path_param} type not of str or '
                        f'pathlib.PosixPath')
    if not isinstance(header, (str, type(None))):
        raise TypeError(f'header:{header} type is not str')
    if not isinstance(footer, (str, type(None))):
        raise TypeError(f'footer:{footer} type is not str')
    if not isinstance(pass_bad, bool):
        raise TypeError(f'pass_bad:{pass_bad} type is not bool')

    if not pcf_path.is_file():
        raise FileNotFoundError(f'Invalid PCF path: {pcf_path}')
    pcf_dict = {}
    pcf_file = pcf_path.open('r')
    header_met = not header
    footer_met = not footer
    for line in pcf_file:
        line = line.rstrip('\n')
        if not header_met:
            header_met = (line == header)
            continue
        if line == footer:
            footer_met = True
            break
        if _blank_line(line):
            continue
        try:
            if line.count('=') != 1:
                raise ValueError(f'More than one "=" present in PCF line: {line}')
            key, value = line.split('=', 1)
            key = key.strip()
            value = value.strip()
            if not value:
                if empty_val:
                    value = ""
                else:
                    raise ValueError(f'No PCF value given for key {key}')
            if not key:
                raise ValueError(f'PCF key missing on line: {line}')
            if not _valid_key(key):
                raise ValueError(f'Invalid PCF key {key}')
        except ValueError as err:
            if pass_bad:
                continue
            raise err
        if key not in pcf_dict:
            pcf_dict[key] = value
        else:
            if isinstance(pcf_dict[key], list):
                pcf_dict[key].append(value)
            else:
                pcf_dict[key] = [pcf_dict[key], value]
    if not header_met:
        raise ValueError(f'PCF is missing header: {header}')
    if not footer_met:
        raise ValueError(f'PCF is missing footer: {footer}')
    pcf_file.close()
    return pcf_dict


def write_pcf(pcf_dict, pcf_path_param, header=None, footer=None):
    """
    Writes the dictionary to a PCF at the specified path, providing
    formatting exceptions with the specified parameters. If a header or
    footer is specified, they will be applied to the beginning and end
    of the PCF.

    Parameters
    ----------
    pcf_dict : dict
    The dictionary to be written to the PCF

    pcf_path_param : str or pathlib.PosixPath
    The path of the PCF to be written

    header : str
    If specified, will be the first line of the PCF

    footer : str
    If specified, will be the last line of the PCF
    """
    if not isinstance(pcf_dict, dict):
        raise TypeError(f'pcf_dict:{pcf_dict} type is not dict')
    if isinstance(pcf_path_param, str):
        pcf_path = Path(pcf_path_param)
    elif isinstance(pcf_path_param, PosixPath):
        pcf_path = pcf_path_param
    else:
        raise TypeError(f'pcf_path_param:{pcf_path_param} type not of str or '
                        f'pathlib.PosixPath')
    if not isinstance(header, (str, type(None))):
        raise TypeError(f'header:{header} type is not str')
    if not isinstance(footer, (str, type(None))):
        raise TypeError(f'footer:{footer} type is not str')

    pcf_file = pcf_path.open('w')
    if header:
        pcf_file.write(f'{header}\n')
    for key, val in pcf_dict.items():
        if isinstance(val, str):
            val_list = [val]
        elif isinstance(val, list):
            val_list = val
        else:
            raise TypeError(f'PCF value for {key} must be a list or str.')
        if not _valid_key(key):
            raise ValueError(f'Bad characters in key: {key}')
        for val_item in val_list:
            if '=' in val_item:
                raise ValueError(f'Bad characters in val: {val_item}')
            pcf_file.write(f'{key}={val_item}\n')
    if footer:
        pcf_file.write(f'{footer}\n')
    pcf_file.close()
