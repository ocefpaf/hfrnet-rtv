from pathlib import Path
from typing import Union

from .parse_config import parse_config


def init(config_path: Union[str, Path]) -> dict:
    """

    Parameters
    ----------
    config_path

    Returns
    -------
    Returns the body of the algorithm section of the v2 yaml.
    """
    if isinstance(config_path, str):
        config_path = Path(config_path)
    if not isinstance(config_path, Path):
        raise ValueError(f"config path is an invalid type: {type(config_path)}")

    _config = parse_config(config_path)

    config: dict = _config['algorithm']
    config['version'] = _config['version']
    config['info'] = _config['info']

    return config
