"""
This module provides a function for parsing a provided YAML configuration file.
"""
import re
from pathlib import Path
from typing import Union

import yaml


def parse_yaml(file: Union[str, Path], encoding="utf-8",
               loader=yaml.SafeLoader) -> dict:
    """
    This function takes in a string path to a YAML configuration file that is
    parsed and returned as a dictionary.

    Parameters
    ----------
    file : str | Path
        A YAML configuration file to be parsed and returned as a dictionary.
    encoding: str, default=utf-8
        File encoding to be used to read the file.
    loader : yaml.Loader, default=yaml.SafeLoader
        A YAML loader class to ingest the config_file.

    Returns
    -------
    dict
        A dictionary of the parsed YAML configuration file.

    """
    if isinstance(file, str):
        config_path = Path(file)
    else:
        config_path = file

    if config_path.exists():
        try:
            with open(config_path, encoding=encoding) as config_in:
                config_dict: dict = yaml.load(config_in, Loader=loader)
            return config_dict
        except yaml.YAMLError as exc:
            raise yaml.YAMLError(f"There was an error {exc}.")

    raise FileNotFoundError("Config file doesn't exist.")


def parse_config(config_file: Union[str, Path], encoding="utf-8",
                 yaml_loader=yaml.SafeLoader) -> dict:
    """
    This function will take in a config file and return a dictionary
    representation

    Parameters
    ----------
    config_file : str | Path
        A YAML configuration file to be parsed and returned as a dictionary.
    encoding : str, default="utf-8"
        File encoding to be used to read the file.
    yaml_loader : yaml.Loader, default=yaml.SafeLoader
        A YAML loader class to ingest the config_file

    Returns
    -------
    dict
        The dict representation of the config file given.

    Raises
    ------
    ValueError
        Will throw a value error if the extension of the config_file do not
        match the regex: \.ya?ml

    """
    if isinstance(config_file, str):
        config_file = Path(config_file)

    if re.match("\.ya?ml", config_file.suffix):
        return parse_yaml(config_file, encoding, yaml_loader)
    else:
        err_msg = f"File given, {config_file} was not recognized as a config"
        raise ValueError(err_msg)
