""" Schema for V2 """
from pathlib import Path
from typing import Any
from schema import And, Schema, Or, Optional, Regex, Use


V2_DEFAULTS = Schema({
    Optional("readonly"): bool,
    Optional("type"): Or("bind", "volume"),
    Optional("tmpfs-mode"): And(Use(int), lambda n: 0o000 <= n <= 0o1777),
    Optional("tmpfs-size"): And(Use(int), lambda n: 0 <= n),
    Optional("propagation"): Or("rprivate", "private", "rshared", "shared", "rslave", "slave"),
    Optional("bind-recursive"): Or("enabled", "disabled", "writable", "readonly"),
    Optional("dereference"): bool
})

__application_schema = Schema({
    # Job Coverage, hopefully no explanation is needed
    "coverage": {
        "start": Or(str, int),
        "end": Or(str, int),
        # I cant explicitly state in the schema that Any type is acceptable so anything that is initialized in the
        # config should be valid. This should be good enough since if an extra value is given it should have a value
        # instead of being left null.
        Optional(str): Use(lambda n: n is not None)
    },
    # Locations that are used to input and output information to the container.
    "io": {
        str: Or(str, Path)
    },
    # This is an optional key to group logging levels together.
    # Consider changing the str option to a choice of the valid logging level strings.
    Optional("logging"): {
        str: Or(str, int)
    },
    # Production location information.
    Regex("^prod(uction$)?"): {
        "site": str,
        Regex("^env(ironment$)?"): str
    },
    # Reference to commonly used locations and variables in the container.
    # See above comment in coverage for rationale behind this Use lambda.
    "ref": {
        str: Use(lambda n: n is not None)
    },
    # Miscellaneous keys that the dev wants to add to their config.
    # See above comment in coverage for rationale behind this Use lambda.
    Optional(str): Use(lambda n: n is not None)
})

__docker_schema = Schema({
    # Docker image to use.
    "image": str,
    # Alternative to a Docker Entrypoint, but the action that docker will take
    # once the container starts.
    "action": {
        "bin": str,
        "script": str,
        "config": str,
        Optional("args"): list
    },
    # Information for the Docker mounts.
    "mount": {
        # Options to be placed across all the mounts created.
        Optional("options"): V2_DEFAULTS,
        # Miscellaneous key for organization or some other task.
        Optional(str): Use(lambda n: n is not None),
        # List of mount pairs to be created for the docker container.
        "pairs": {
            str: Or(dict, str)
        }
    },
    # Docker arguments to modify attributes about the container.
    Optional("args"): {
        str: Use(lambda n: n is not None)
    },
    # Environment variables to pull from the host machine to transfer to the
    # container.
    Optional("env_vars"): list,
    # Information about the Docker container.
    "container": {
        str: str
    }
})

__info_schema = Schema({
    str: Use(lambda n: n is not None)
})

APP_SCHEMA = Schema({
    "version": Or("2.0", 2.0),
    Optional("info"): __info_schema,
    "algorithm": __application_schema
})

# Consider renaming to LAUNCH_SCHEMA
FULL_SCHEMA = Schema({
    "version": Or("2.0", 2.0),
    Optional("info"): __info_schema,
    "algorithm": __application_schema,
    "docker": __docker_schema
})


def is_valid(config: dict, schema: Schema=FULL_SCHEMA):
    """

    Parameters
    ----------
    schema: Schema = V2_SCHEMA
    config
    """
    return schema.validate(config)
