import os
from datetime import datetime, timezone
from typing import Union
import warnings

import schema

from .config_schema import is_valid, V2_DEFAULTS
from .mount import Bind, Volume, TmpFS


DEFAULTS = {
    "readonly": False,
    "type": "bind",
    "tmpfs-mode": 0o1777,
    "dereference": False,
    "propagation": "rprivate"
}


def get_image(config) -> str:
    return str(config["docker"]["image"])


def get_defaults(config) -> dict:
    user_options = config["docker"]["mount"]["options"]
    defaults = DEFAULTS.copy()
    defaults.update(user_options)
    return defaults


def get_raw_args(config) -> dict:
    return dict(config["docker"]["args"])


def make_args(arguments: dict) -> list:
    docker_arg_list = list()
    docker_arg_list.append("--rm")
    for key, value in arguments.items():
        # take care of ulimit which will be nested
        if isinstance(value, dict):
            for sub_key, sub_value in value.items():
                docker_arg_list.append(f'--{key}')
                docker_arg_list.append(f"{sub_key}={sub_value}")
        # take care of the rest of the individual args
        else:
            docker_arg_list.append(f'--{key}={value}')
    return docker_arg_list


def get_raw_flags(config) -> list[str]:
    return config["docker"].get("flags", [])


def make_flags(flags: list, interactive: bool=False) -> list[str]:
    res: list[str] = list()
    singlets: str = None
    f: str
    if interactive:
        singlets = "-it"
    for f in flags:
        if f.count('-') <= 1:  # -it
            f = f.strip('-')
            if singlets is None:
                singlets = f"-{f}"
            else:
                singlets += f
        else:  # --detach
            res.append(f)
    if singlets is not None:
        res.append(singlets)
    return res


def get_raw_mounts(config) -> dict:
    return dict(config["docker"]["mount"]["pairs"])


def make_mounts(mounts: dict, defaults: dict) -> list:
    mount_list = list()

    types = {
        "bind": Bind,
        "volume": Volume,
        "tmpfs": TmpFS
    }

    # Check defaults
    try:
        is_valid(defaults, V2_DEFAULTS)
    except schema.SchemaError as err:
        raise ValueError("Default options set are invalid.") from err

    def make_mount(destination: str, options: Union[dict, str]):
        # TODO: To support recursive dereferenceing some refactoring might be needed.

        default_type = types[defaults['type']]
        if isinstance(options, str):
            # value is a string
            instance_options = defaults.copy()
            instance_options["dest"] = destination
            instance_options["source"] = options
            return default_type(**instance_options)
        elif isinstance(options, dict):
            # value is a dict
            instance_type = types[options.get("type", defaults["type"])]
            instance_options = defaults.copy()
            instance_options.update(options)
            instance_options["dest"] = destination
            return instance_type(**instance_options)
        raise ValueError(f"Unrecognized type {type(options)}, value={options}")

    dest: str
    value: Union[dict, str]
    for dest, value in mounts.items():
        mount = make_mount(dest, value)
        mount_list += mount.get_list()
    return mount_list


def get_raw_env_vars(config) -> list:
    return list(config["docker"].get("env_vars", []))


def make_env_vars(env_vars) -> list[str]:
    res: list[str] = list()
    warn_msg = "The environment variable '{}' returned no value. Skipping."
    for var in env_vars:
        cleaned = var.strip(" $")
        value = os.environ.get(cleaned, None)
        if value is None:
            warnings.warn(warn_msg.format(cleaned))
            continue
        res += ["--env", f"{cleaned}={value}"]
    return res


def make_container_name(config) -> str:
    container = config["docker"]["container"]
    err_msg = ("'{}' is a required key in docker:container. "
               "Review the run config and try again.")
    warn_msg = "'{}' was not found in {}. {}"

    # Return early if a container name is already chosen
    preset_name: str = container.get("name", None)
    if preset_name is not None:
        return preset_name

    # Get required values
    try:
        sat = container["sat"]
    except KeyError as err:
        raise ValueError(err_msg.format("sat")) from err
    try:
        project = container["proj"]
    except KeyError as err:
        raise ValueError(err_msg.format("proj")) from err
    try:
        caseid = container["caseid"]
    except KeyError:
        warnings.warn(warn_msg.format("caseid", "config info",
                                      "Grabbing current timestamp."))
        current_time = datetime.now(timezone.utc)
        caseid = current_time.strftime("d%Y%m%dt%H%M%S%f")[:-5]

    # Get optional values
    instr = container.get("instrument", None)
    product = container.get("product", None)
    coverage: str = container.get("coverage", None)

    sat_instr = sat
    if instr:
        sat_instr += f".{instr}"
    else:
        warnings.warn(warn_msg.format("instr", "docker:container", ""))

    proj_prod = project
    if product:
        proj_prod += f".{product}"
    else:
        warnings.warn(warn_msg.format("product", "docker:container", ""))

    container_name = f"{sat_instr}-{proj_prod}-{caseid}"
    if not coverage:
        warnings.warn(warn_msg.format("coverage", "docker:container",
                                      "Grabbing algorithm:coverage."))
        start: str = config["algorithm"]["coverage"].get("start", None)
        end: str = config["algorithm"]["coverage"].get("end", None)
        if start not in (None, ""):
            coverage = "-"
            coverage += f"s{start}"
        if end not in (None, ""):
            if start not in (None, ""):
                coverage += "_"
            else:
                coverage = "-"
            coverage += f"e{end}"
        return container_name + f"{coverage}"

    return container_name + f"-{coverage}"


def get_action(config):
    err_msg = ("'{}' is a required key in docker:action. "
               "Review the run config and try again.")
    warn_msg = "'{}' was not found in {}. {}"

    # Get required values
    try:
        binary = config["docker"]["action"]["bin"]
    except KeyError:
        warnings.warn(warn_msg.format("bin", "docker:action",
                                      "Using 'python'."))
        binary = "python"
    try:
        script = config["docker"]["action"]["script"]
    except KeyError as err:
        raise ValueError(err_msg.format("script")) from err
    try:
        self = config["docker"]["action"]["config"]
    except KeyError as err:
        raise ValueError(err_msg.format("config")) from err

    # Get optional argument list
    args = None
    try:
        args = config["docker"]["action"]["args"]
    except KeyError:
        # This error can be dropped
        pass

    action = [binary, script, self]
    if args:
        action.extend(args)
    return action


def make_cmd(config, interactive: bool=False) -> list:
    """
    Creates a docker run cmd in the form of a list while packaging
    arguments for helper functions. All arguments come directly
    from _parse_yaml and as such do not need to be modified from it,
    merely passed through

    Parameters
    ----------
    config : dict
        standardized ccap v2 config dict.
    interactive : bool
        if True, Allows user to interact with (bash) shell of the
        docker container. The python command at the end is
        replaced with '/bin/bash'. '-it' flag is added as an
        item to the output list after "docker" and  "run".

    Returns
    ---------
    list:
        list of strings which are ready to be combined into a docker run command
    """
    validation = config.get("info", {}).get("validation", True)
    if validation:
        try:
            is_valid(config)
        except schema.SchemaError as err:
            raise ValueError("Config did not match schema.") from err

    # Get basics
    image: str = get_image(config)
    docker_defaults: dict = get_defaults(config)
    docker_args: dict = get_raw_args(config)
    docker_flags: list = get_raw_flags(config)
    env_args: list = get_raw_env_vars(config)
    mount_args: dict = get_raw_mounts(config)
    container_name: str = make_container_name(config)
    python_args: list = get_action(config)

    # Initialize docker_run list
    docker_cmd_list = ['docker', 'run']
    # Add container name, docker args, mount pairs, image, and python_args
    docker_cmd_list += ["--name", container_name]
    docker_cmd_list += make_flags(docker_flags, interactive)
    docker_cmd_list += make_mounts(mount_args, docker_defaults)
    docker_cmd_list += make_args(docker_args)
    docker_cmd_list += make_env_vars(env_args)
    docker_cmd_list += [image]
    if interactive:
        docker_cmd_list += ['/bin/bash']
    else:
        docker_cmd_list += python_args

    # Ensure all items in cmd are strings
    docker_cmd_list = [str(item) for item in docker_cmd_list]
    return docker_cmd_list
