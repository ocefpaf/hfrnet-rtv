""" ingest.py
Author:      Perry Bunn
Email:       perry.bunn@noaa.gov
Description: Ingest, contains classes and methods related to file ingest.
"""
from __future__ import annotations

try:
    from collections.abc import Iterable  # for >=py39
except ImportError:
    # Note: typing.Iterable is deprecated in py37, and will be removed once py39
    #       is EOL. See PEP 563 and 585
    from typing import Iterable  # for <=py38


import yaml


class Concatenate:
    """ YAML String Concatenation

    This class implements a custom constructor that extends yaml.safe_loader.

    Parameters
    ----------
    strings: Iterable
             An iterable of strings to join.

    Attributes
    ----------
    iterable: list
    merged: str

    Methods
    -------
    flatten(Iter)
        Flatten N nested iterator obj into a single generator obj.

    Example
    -------
    Below is a simple yaml that uses the !concat tag to join the anchor in a[b]
    to create the value `helloworld` in a[c]::
        ---
        a:
          b: &b "hello"
          c: !concat [*b, "world"]

        >>> {'a':{'b':"hello", 'c': "helloworld"}}

    Notes
    -----
    This class is heavly influenced by the following articles:
    https://stackoverflow.com/questions/40631913/concatenation-of-yaml-anchors-with-another-string-in-keys
    https://matthewpburruss.com/post/yaml/
    """

    iterable: list
    merged: str

    def __init__(self, strings: Iterable):
        self.iterable = list(self.flatten(strings))
        self.merged = ''.join(str(i) for i in self.iterable)

    def __repr__(self):
        return f"Concatenate({self.iterable})"

    def __str__(self):
        return f"{self.merged}"

    def flatten(self, array):
        """ flatten
        Flatten N nested iterator obj into a single generator obj.

        Parameters
        ---------
        array: Iterable
            Any iterable obj to be walked over

        Example
        -------
        For any iterable obj like a 3d list returns a 1d generator::
            list_3d = [[["hello"],"world"]]
            list_1d = Concatenate.flatten(list_3d)
            print(list_1d)

            >>> ["hello", "world"]
        """
        for x in array:
            if isinstance(x, Iterable) and not isinstance(x, (str, bytes)):
                yield from self.flatten(x)
            else:
                yield x

    @classmethod
    def constructor(cls, loader: yaml.SafeLoader,
                    node: yaml.nodes.Node) -> Concatenate:
        """ Getter method for the constructor of the Concatenate class.

        Parameters
        ----------
        loader: yaml.SafeLoader
        node: yaml.nodes.Node

        Returns
        -------
        Concatenate

        """
        return Concatenate(loader.construct_yaml_seq(node))


def get_loader():
    """Add custom constructors to PyYAML SafeLoader."""
    loader = yaml.SafeLoader
    loader.add_constructor("!concat", Concatenate.constructor)
    return loader
