from abc import abstractmethod
from pathlib import Path


# https://docs.docker.com/engine/reference/commandline/run


class Mount:
    """ Docker mounts are ways to create persistent data and file structure to
    docker containers.
    """
    dst: str
    src: str
    readonly: bool
    type: str

    def __init__(self, dest, source, readonly, dereference=False):
        self.dst = dest
        if dereference:
            source = Path(source).resolve().as_posix()
            self.src = source
        else:
            self.src = source
        self.readonly = readonly

    @abstractmethod
    def get_list(self):
        raise NotImplementedError


class Bind(Mount):
    """ Bind mounts have limited functionality compared to volumes. When you use
    a bind mount, a file or directory on the host machine is mounted into a
    container. The file or directory is referenced by its full path on the host
    machine.
    """

    # The propagation should not be changed from the default 'rprivate' unless
    # you know what you are doing. Leaving it as none or not assigning
    # propagation will choose the docker default, 'rprivate'.
    propagation: str
    type = "bind"

    def __init__(self, **kwargs):
        dest = kwargs.get("dest")
        source = kwargs.get("source")
        readonly = kwargs.get("readonly", False)
        propagation = kwargs.get("propagation", "rprivate")
        dereference = kwargs.get("dereference", False)
        super(Bind, self).__init__(dest, source, readonly, dereference)
        self.propagation = propagation

    def get_list(self):
        return ["--mount",
                f"type={self.type},src={self.src},dst={self.dst},readonly={self.readonly}"]


class Volume(Mount):
    """ Volumes are created and managed by Docker. A given volume can be mounted
    into multiple containers simultaneously. When no running container is using
    a volume, the volume is still available to Docker and is not removed
    automatically. Volumes also support the use of volume drivers, which allow
    you to store your data on remote hosts or cloud providers, among other
    possibilities.
    """
    src: str
    type = "volume"

    def __init__(self, **kwargs):
        dest = kwargs.get("dest")
        source = kwargs.get("source")
        readonly = kwargs.get("readonly", False)
        dereference = kwargs.get("dereference", False)
        super(Volume, self).__init__(dest, source, readonly, dereference)

    def get_list(self):
        readoption = ""
        if self.readonly:
            readoption = ":ro"
        return ["-v", f"{self.src}:{self.dst}{readoption}"]


class TmpFS(Mount):
    """ A tmpfs mount is not persisted on disk, either on the Docker host or
    within a container. It can be used by a container during the lifetime of the
    container, to store non-persistent state or sensitive information.
    """
    mode: int
    size: int
    type = "tmpfs"
    exec = True

    def __init__(self, **kwargs):
        dest = kwargs.get("dest")
        mode = kwargs.get("tmpfs-mode", 1777)
        size = kwargs.get("tmpfs-size", 0)
        exec_perm = kwargs.get("exec", True)
        super().__init__(dest, None, False, False)
        self.mode = mode
        self.size = size
        self.exec = exec_perm

    def get_list(self):
        if not self.exec:
            return ["--tmpfs", f"{self.dst}"]
        return ["--tmpfs", f"{self.dst}:exec"]
