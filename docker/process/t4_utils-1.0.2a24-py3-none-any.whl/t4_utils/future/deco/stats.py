import functools
import logging
import signal
import subprocess
from pathlib import Path
import time
from threading import Thread

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

DOCKER_STATS_FILE_NAME = "./dockerstats.csv"
DOCKER_LOG_HEADERS = "Container, ID, CPUPerc, MemUsage, PIDs\n"
DOCKER_STATS_FORMAT = "{{.Container}}, {{.ID}}, {{.CPUPerc}}, {{.MemUsage}}, {{.PIDs}}"


def wait_until_docker_starts(docker_name, check_interval=0.5, timeout=300):
    """
    Parameters
    ----------
    timeout : int
        Number of seconds to wait for the docker container to start.
    docker_name : str
        The name of the Docker container to wait for.

    """
    def timeout_handle(signum, frame):
        """
        Waits until a Docker container with the given name starts running.

        Raises
        ------
        TimeoutError
            If the process takes too long to start.

        """
        raise TimeoutError("Process took too long to start.")

    signal.signal(signal.SIGALRM, timeout_handle)
    signal.alarm(timeout)

    try:
        while True:
            cmd_check = ["docker", "ps", "-a", "-f", f"name={docker_name}"]
            proc = subprocess.Popen(cmd_check, stdout=subprocess.PIPE)
            output, error = proc.communicate()
            if docker_name in output.decode():
                signal.alarm(0)
                return True
            logger.info(f"{docker_name} is not started yet. Waiting...")
            time.sleep(check_interval)  # Sleep for half a second
    except TimeoutError as e:
        logger.error(f"Timed out waiting for {docker_name} container to start.")
        logger.info(f"Ending stat capture attempt.")
        logger.debug(f"{e}")
    return False


def wait_until_container_exits(docker_name):
    """
    Parameters
    ----------
    docker_name : str
        The name of the Docker container to wait for.

    """
    while True:
        cmd_check = ["docker", "ps", "-a", "-f", f"name={docker_name}"]
        proc = subprocess.Popen(cmd_check, stdout=subprocess.PIPE)
        output, error = proc.communicate()
        if docker_name in output.decode():
            return
        time.sleep(0.5)  # Sleep for half a second


def stats(func, file_name=DOCKER_STATS_FILE_NAME):
    """
    Parameters
    ----------
    func : function
        The function to be wrapped.
    file_name : str, optional
        The name of the file to write stats of. Default is DOCKER_STATS_FILE_NAME.
    """
    # TODO-perry: Refactor to use docker.sock.

    @functools.wraps(func)
    def stats_runner(*args, **kwargs):
        docker_name = args[0][3]
        thread = Thread(target=func, args=args, kwargs=kwargs)
        thread.start()

        res = wait_until_docker_starts(docker_name)

        if res:  # container started
            extract_docker_stats_cmd = [f"docker stats {docker_name} --format '{DOCKER_STATS_FORMAT}'"]

            with open(file_name, mode='w+') as file:
                file.write(DOCKER_LOG_HEADERS)
                file.flush()
                try:
                    proc = subprocess.Popen(extract_docker_stats_cmd,
                                            stdout=file, stderr=file, shell=True)
                    logger.info("Spooled stats watcher successfully.")
                except ValueError as err:
                    logger.error("Error encountered while trying to spool stats watcher.")
                    logger.error(err)
                else:
                    wait_until_container_exits(docker_name)
                    proc.terminate()

        thread.join()

    return stats_runner
