"""
Program name:       docker_wrapper.py

Date:               8 Sep 2021

History:            Edit to  allow for both strings and Path objects in:
                    source, destination or mixed as a list of source files

Contributors:       Morgan Hobson, Eric Buzan, Trevor Clack

Description:

    create_docker_run_cmd : Parses a configuration yaml and assembles an
    ordered list of commands ready to be used by the subprocess module.
    Several supporting functions are included to support this main task
"""
import os
import yaml


def _parse_yaml(input_yaml):
    """A helper function which parses the standardized ccap config file.
    After parsing into appropriate keys, this function also calls:
     _create_mounts_list
     _create_python_run_cmd
     _create_container_name
    This puts the bulk of the processing in this one function for the
    purpose of passing the output in a "ready-to-be-assembled" state
    to create_docker_run_cmd

    Parameters
    ----------
    input_yaml : string

    path to a filled out standardized ccap config yaml file

    Returns
    -------
    image           : str
        path to docker image

    docker_args     : dict
        The arguments to be added to the "docker run" cmd. These
        will be key:value pairs as usually provided to docker run.
        eg. --rm=False shows in this dict as {rm:False}

    mount_args      : list
        The list ouput provided by _create_mounts_list. The list is a
        split of the relevant commands provided to docker

    container_name  : list
        A list containing the single string which is the
        container name. Outputted from _create_container_name

    python_args     : list
        list of 3 things:
         -string path to python binary
         -string path to python script
         -string path to application yaml providing python args
        provided by _create_python_run_cmd

    other_args      : list
        optional (default None)
        list of other docker options users wish to use which aren't
        available in the standardized CCAP config yaml
    """
    with open(input_yaml) as file:
        yaml_dict = yaml.safe_load(file)
    docker_info = yaml_dict['docker_info']
    image = docker_info['image']
    docker_args = docker_info['docker_args']
    # add --rm to docker_args as true if blank or non-existent
    if docker_args.get('rm', None) is None:
        docker_args['rm'] = 'true'
    # add user ID to docker_args if blank or non-existent
    if docker_args.get('user', None) is None:
        docker_args['user'] = os.getuid()
    mount_pairs = docker_info['mount_pairs']
    mount_args = _create_mounts_list(mount_pairs)
    python_info = docker_info['python_info']
    python_args = _create_python_run_cmd(python_info)
    #other_args = filter_none_objs(docker_args.pop('other_args', []))
    other_args = docker_args.pop('other_args', [])
    container_info = docker_info['container_name']
    container_name = _create_container_name(container_info)
    return image, docker_args, mount_args,\
            container_name, python_args, other_args


def _create_mounts_list(mount_config: list) -> list:
    """
    Creates a list of --mount options that can be added to the
    'docker run' command.

    Each item of the list can add a mount in one of two ways:

    1. A string denoting the path to the mount on the disk. In this
       case the source and destination will be set to this string and
       the type will be set to "bind".

    2. A dict denoting each of the key/value options for the mount. The
       only required key is "src". If "dst" is not provided, it will be
       set to the same value as "src". If "type" is not provided, it
       will be set to "bind".

       Although the source and destination can be interpreted by the
       "docker run" command in different ways, for this function they
       must be represented by "src" and "dst".

       If the user wishes to set a non key/value flag in the mount
       options such as "readonly", the user must provide the flag as
       a key and the value as `True`.

       All other options can be provided with arbitrary key/value
       combinations, although escaped csv values for volume-opt are not
       currently supported.

    Parameters
    ----------
    mount_list : list[Union[str, dict]]

    Returns
    -------
    mounts : list[str]
    """
    mount_list = []

    if not isinstance(mount_config, list):
        raise TypeError(f'mount_config:{mount_config} invalid type\n'
                        f'must be a list, is of type {type(mount_config)}')

    for mount_item in mount_config:
        mount_list.append('--mount')

        if isinstance(mount_item, str):
            mount_val = [f'dst={mount_item}',
                         f'src={mount_item}',
                         'type=bind']

        elif isinstance(mount_item, dict):
            mount_val = []

            if 'src' not in mount_item:
                raise KeyError('src key required in mount dict config\n'
                               f'mount:{mount_item}')
            if 'dst' not in mount_item:
                mount_item['dst'] = mount_item['src']
            if 'type' not in mount_item:
                mount_item['type'] = 'bind'

            for key, val in mount_item.items():
                if isinstance(val, bool):
                    mount_val.append(f'{key}')
                else:
                    mount_val.append(f'{key}={val}')

            # sorting for testing purposes
            mount_val.sort()

        else:
            raise TypeError(f'mount:{mount_item} invalid type\n'
                            f'must be str or dict, is of type '
                            f'{type(mount_item)}')

        mount_list.append(','.join(mount_val))

    return mount_list


def _create_container_name(container_info: dict) -> list:
    """
    container_info is a dict with the following keys
        sat: str
        proj: str
        caseid: str. generally in datetime format, but flexible,
        instr: str. # Optional
        prod: str. # Optional
        cov: str. # Optional
    Function used to create a name for the container using our Argo wf
    naming convention.

    Parameters
    ----------
    sat : str
        Satellite to be included in container name.
    project : str
        Project associated with algorithm that is being run.
    time_dt : datetime object
        Datetime object associated with data being processed.
    instr : str
        Instrument where data being processed derives from. If the
        parameter is set to None it will be ignored.
    product : str
        Product that is going to be produced during processing. If the
        parameter is set to None it will be ignored.
    coverage : str
        Coverage associated with data being processed. If the parameter
        is set to None it will be ignored.
    """
    sat = container_info['sat']
    project = container_info['proj']
    caseid = container_info['caseid']
    instr = container_info.get('instr', None)
    product = container_info.get('prod', None)
    coverage = container_info.get('cov', None)
    sat_instr = sat
    if instr:
        sat_instr = f"{sat}.{instr}"

    proj_prod = project
    if product:
        proj_prod = f"{project}.{product}"

    if coverage:
        return ['--name', f"{sat_instr}-{proj_prod}-{caseid}-{coverage}"]
    return ['--name', f"{sat_instr}-{proj_prod}-{caseid}"]


def _create_python_run_cmd(python_info: dict) -> list:
    """
    dictionary with three keys:
        python: str,
        script: str,
        application_yaml: str
    This helper function creates a python run command that will consist
    of the Python interpreter, script to be run, and any required and
    optional parameters that the script makes use of.

    Parameters
    ----------
    python : str
        Python interpreter to be used to run processing code.
        Path to script that is going to be used to do processing within
        container.
    application_yaml : str
        Path too yaml with relevant arguments for the Python script being ran

    Returns
    -------
    List of strings that contains the full python run command.
    """
    # assign python to key if it's either left blank or removed from yaml
    python_cmd = python_info.get('python', 'python') or 'python'
    script = python_info['script']
    application_yaml = python_info['application_yaml']
    if not isinstance(python_cmd, str):
        raise TypeError(f"python_cmd:{python_cmd} must be a string")

    if not isinstance(script, str):
        raise TypeError(f"script:{script} must be a string")

    python_run_cmd = [python_cmd, script, application_yaml]

    return python_run_cmd


def _create_docker_arg_list(docker_args, other_args):
    docker_arg_list = []
    for key, value in docker_args.items():
        # take care of ulimit which will be nested
        if isinstance(value, dict):
            for sub_key, sub_value in value.items():
                docker_arg_list.append(f'--{key}')
                docker_arg_list.append(f"{sub_key}={sub_value}")
        # take care of the rest of the individual args
        else:
            docker_arg_list.append(f'--{key}={value}')
    # add in other_args (which is a list of single items or list of commands)
    if other_args:
        for other_arg in other_args:
            if isinstance(other_arg, str):
                docker_arg_list.append(other_arg)
            elif isinstance(other_arg, list):
                for item in other_arg:
                    if not isinstance(item, (str, bool, float, int)):
                        raise TypeError(f"""
                        error with {item} in "docker args" --> "other args".
                        Must be a string, number or booleean
                        """)
                docker_arg_list.extend(other_arg)
            else:
                raise TypeError(f"""Error with {other_arg} in docker args:
                other arguments must be string (eg. "--net=host")
                or ordered list of docker options(e.g. ["--net", "host"])
                """)

    # Filter None objects (which can happen if for example:
    # an "other_args" key exists with a sub-list in yaml but is left blank
    #docker_arg_list = list(filter(None.__ne__, docker_arg_list))
    return docker_arg_list


def create_docker_run_cmd(input_yaml, interactive=False):
    """
    Creates a docker run cmd in the form of a list while packaging
    arguments for helper functions. All arguments come directly
    from _parse_yaml and as such do not need to be modified from it,
    merely passed through

    Parameters
    ----------
    input_yaml : string
        path to a filled out standardized ccap config yaml file.
    interactive : bool
        if True, Allows user to interact with (bash) shell of the
        docker container. The python command at the end is
        replaced with '/bin/bash'. '-it' flag is added as an
        item to the output list after "docker" and  "run".


    Returns
    ---------
    list
        list of strings which are ready to be combined into a docker run command
    """
    image, docker_args, mount_args, container_name,\
            python_args, other_args = _parse_yaml(input_yaml)

    # consolidate docker_args and other_args dict then add
    docker_arg_list = _create_docker_arg_list(docker_args, other_args)

    # Initialize docker_run list
    docker_cmd_list = ['docker', 'run']
    if interactive:
        docker_cmd_list += ['-it']
    # Add container name, mount pairs, docker args, image and python_args
    docker_cmd_list += container_name
    docker_cmd_list += mount_args
    docker_cmd_list += docker_arg_list
    docker_cmd_list += [image]
    if interactive:
        docker_cmd_list += ['/bin/bash']
    else:
        docker_cmd_list += python_args

    docker_cmd_list = [str(item) for item in docker_cmd_list]
    return docker_cmd_list
