"""
This module provides a function for parsing a provided YAML configuration file.
"""

from pathlib import Path
import yaml


def parse_config(config_file: str) -> dict:
    """
    This function takes in a string path to a YAML configuration file that is
    parsed and returned as a dictionary.

    Parameters
    ----------
    config_file : str
        A YAML configuration file to be parsed and returned as a dictionary.

    Returns
    -------
    dict
        A dictionary of the parsed YAML configuration file.

    """

    config_path = Path(config_file)

    if config_path.exists():
        try:
            with open(config_path) as config_in:
                config_dict: dict = yaml.safe_load(config_in)
            return config_dict
        except yaml.YAMLError as exc:
            raise yaml.YAMLError(f"There was an error {exc}.")

    raise FileNotFoundError("Config file doesn't exist.")
