"""
ccap_utils.application_init is the module defining all functionality
that should be called at the top of the script running inside a CCAP
container. This is module currently only consists of the
application_init() function.

This module should be used by the scripts running inside the docker
container but not the scripts used to launch the container itself. For
functions that facilitate the launch of the docker container see the
t4_utils.ccap.docker_wrapper module.
"""
import os
from pathlib import Path
import shutil
from typing import Union
import yaml


def _setup_validate_dst(dst):
    """Makes sure dst is available"""
    if dst.exists():
        raise FileExistsError(f'dst:{dst} already present')
    dst.parent.mkdir(exist_ok=True, parents=True)


def _setup_link(transfer):
    """Link according to transfer"""
    src = Path(transfer['src'])
    dst = Path(transfer['dst'])
    if not src.exists():
        raise FileNotFoundError('Missing link src:{src}')
    _setup_validate_dst(dst)
    dst.symlink_to(src)


def _setup_copy(transfer):
    """Copy according to transfer"""
    src = Path(transfer['src'])
    dst = Path(transfer['dst'])
    _setup_validate_dst(dst)
    if src.is_file():
        shutil.copyfile(src, dst)
    elif src.is_dir():
        shutil.copytree(src, dst)
    else:
        raise FileNotFoundError('Missing copy src:{src}')


def _setup_emptydir(transfer):
    """Mkdir according to transfer"""
    dst = Path(transfer['dst'])
    dst.mkdir(exist_ok=True, parents=True)


def _setup(config_setup):
    """Handling for config['setup']"""
    if 'file_transfer' in config_setup:
        for transfer in config_setup['file_transfer']:
            if 'method' not in transfer or transfer['method'] == 'link':
                _setup_link(transfer)
            elif transfer['method'] == 'copy':
                _setup_copy(transfer)
            elif transfer['method'] == 'emptydir':
                _setup_emptydir(transfer)
            else:
                raise ValueError('Invalid file transfer method:'
                                 f'{transfer["method"]}')

    if 'cwd' in config_setup:
        Path(config_setup['cwd']).mkdir(exist_ok=True, parents=True)
        os.chdir(config_setup['cwd'])


def _algorithm_spec(config_algorithm_spec):
    """Handling for config['algorithm_spec']"""
    algorithm_spec_kv = {}

    for arg in config_algorithm_spec:
        if arg['name'] in algorithm_spec_kv:
            raise KeyError(f'algorithm_spec name:{arg["name"]} '
                           'used more than once')
        algorithm_spec_kv[arg['name']] = arg['value']

    return algorithm_spec_kv


def _resolve_out_log_dir(config_dir, dir_type):
    """Handling for config['outdir'] and config['logdir']
    Input logdir or outdir may contain either
        * a string referring to a Path (for single outdir/logdir)
        * dict with keys (for multiple outdir/logdir)
            - `name` containing name of outdir/logdir
            - `path` containing path of the outdir/logdir

    Outputs either
        * a Path for single outdir/logidr
        * dict for multiple outdir/logdir with form
            {`name`: pathlib.Path(`path`)}

    Parameters
    ----------
    config_dir : Union(str|list)
        string or list of dict containing paths
    dir_type : str
        either `logdir` or `outdir`. useful to raise proper error for
        easy debugging.

    Returns
    -------
    Union(Path|dict)
        path(s) of `outdir` or `logdir`. In case of multiple paths, the
        return value is dict containing names and paths of the multiple
        outdir/logdir

    Raises
    ------
    KeyError
        duplicate `name` values are found in input
    TypeError
        anything other than list or str.
    """
    dir_kv = {}

    if isinstance(config_dir, list):
        for arg in config_dir:
            if arg['name'] in dir_kv:
                raise KeyError(f'{dir_type} name:{arg["name"]} '
                               'used more than once')
            dir_kv[arg['name']] = Path(arg['path']).resolve()
    elif isinstance(config_dir, str):
        dir_kv = Path(config_dir).resolve()
    else:
        raise TypeError(f'{dir_type} should be of type list or str,'
                        f'given type : {type(config_dir)}')

    return dir_kv


def application_init(config_path: Union[str, Path]) -> dict:
    """
    application_init() parses the specifications of the CCAP
    configuration yaml stored at config_path and performs any initial
    setup described there. This yaml must follow the standardized
    format outlined at:

    https://docs.google.com/document/d/1Qe-nzOOOzj1jMKszuF3oMY-B_OdN-32xiWJGAHAUr8w/edit?usp=sharing

    application_init() should be the first call made in the algorithm
    script.

    Parameters
    ----------
    config_path: str or pathlib.Path

        The path to the CCAP configuration yaml defined as a str or
        pathlib.Path object.

    Return
    ------
    info: dict

        The dictionary defining the specifications and behavior of the
        algorithm script that follows this initial setup. Will contain
        three keys:

        'outdir': The directory where output files should be stored
             after execution, defined as an absolute pathlib.Path object.
             If config yaml lists 'outdir' as relative, will be resolved
             according to current directory after setup.

        'logdir': The directory where log files should be stored after
             execution, defined as an absolute pathlib.Path object.
             If config yaml lists 'outdir' as relative, will be resolved
             according to current directory after setup.

        'spec': The dictionary where all input values needed to run the
             algorithm script are defined
    """
    if not isinstance(config_path, (str, Path)):
        raise TypeError(f'config_path:{config_path} must be of type str or '
                        'pathlib.Path\n'
                        f'Is of type:{type(config_path)}')

    with open(config_path) as config_stream:
        config = yaml.safe_load(config_stream)['application_info']

    if 'setup' in config:
        _setup(config['setup'])
    algorithm_spec_kv = _algorithm_spec(config['algorithm_spec'])

    info = {
        'outdir': _resolve_out_log_dir(config['outdir'], 'outdir'),
        'logdir': _resolve_out_log_dir(config['logdir'], 'logdir'),
        'spec': algorithm_spec_kv
    }
    return info
