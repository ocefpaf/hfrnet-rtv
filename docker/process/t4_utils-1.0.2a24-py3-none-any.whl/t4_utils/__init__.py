"""
This library provides utility functions commonly used for developing
ASSIST T4 workflows.
"""

import logging

# If the logger is not set in the main program don't log anything
logging.getLogger(__package__).addHandler(logging.NullHandler())
