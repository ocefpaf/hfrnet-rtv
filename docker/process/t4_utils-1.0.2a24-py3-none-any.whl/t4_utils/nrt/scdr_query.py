"""
The nrt_utils.scdr_query module is meant to provide wrapper functions for the
SCDR RESTful API. Currently only the query request is included, though
the list request may be added later
"""
import requests

from datetime import datetime, timedelta
from typing import Union, Optional


# pylint: disable=too-many-branches
def scdr_query(datasets: Union[str, list[str]], satname: Optional[str]=None, stime: Optional[datetime]=None,
               etime: Optional[datetime]=None, since: Optional[Union[datetime, timedelta]]=None):
    """
    scdr_query provides a wrapper for the query request to the SCDR
    RESTful API (http://rhw9120.star1.nesdis.noaa.gov/SCDRWeb/help.html).
    Currently all requests are made for application/json responses, so
    scdr_query returns a dict.

    The only required argument is 'datasets', all other arguments will
    only be applied to the request if they are given a value other than
    None. The query request allows for granule area filtering, but that
    is not currently implemented here. The microseconds and time zones
    of datetime arguments are ignored.

    An HTTPError will be raised if the response has a status code other
    than 200. This can result from bad query arguments or connection
    errors. As an exception to this, if a 400 error is raised due to
    the query giving an empty result, an empty list will be returned.

    Parameters
    ----------
    datasets : list of strings
    The types of files to query, eg. ['GITCO', 'GHRR']

    satname : str
    The satellite to query, eg. 'NOAA-19'

    stime : datetime
    The beginning observation time of the files. Files that end after
    the stime argument will be included.

    etime : datetime
    The ending observation time of the files. Files that start before
    the etime argument will be included.

    since : datetime
    The beginning ingestion time of the files. Files that were ingested
    by SCDR after the since argument will be included.
    """
    if isinstance(datasets, str):
        params = {'type': datasets}
    elif isinstance(datasets, list):
        for dataset in datasets:
            if not isinstance(dataset, str):
                raise TypeError(f'{dataset} is not of str type')
        params = {'type': ','.join(datasets)}
    else:
        raise TypeError(f'{datasets} is not of list or str type')

    url = 'http://scdr-api.star1.nesdis.noaa.gov' \
          '/SCDRWeb/service/scdr-files/query'
    header = {"Content-Type": "application/json"}
    isostr = '%Y-%m-%dT%H:%M:%S'
    if stime is not None:
        if not isinstance(stime, datetime):
            raise TypeError(f'{stime} is not of datetime type')
        params['stime'] = stime.strftime(isostr)
    if etime is not None:
        if not isinstance(etime, datetime):
            raise TypeError(f'{etime} is not of datetime type')
        params['etime'] = etime.strftime(isostr)
    if since is not None:
        if isinstance(since, timedelta):
            params['since'] = (datetime.utcnow() - since).strftime(isostr)
        elif isinstance(since, datetime):
            params['since'] = since.strftime(isostr)
        else:
            raise TypeError(f'{since} is not of datetime or timedelta type')
    if satname is not None:
        if not isinstance(satname, str):
            raise TypeError(f'{satname} is not of str type')
        params['satname'] = satname

    resp = requests.get(url, headers=header, params=params)
    print(resp.text)
    if resp.text == f'There is no file of {params["type"].upper()} ' \
                    f'during the specified period':
        return []
    resp.raise_for_status()
    return resp.json()
