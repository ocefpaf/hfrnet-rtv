"""
argo.py provides functions for standardizing interactions with argo
workflows.
"""
from datetime import datetime as dt
from pathlib import Path
import re
import subprocess


#pylint: disable=too-many-arguments
def workflow_name(user, sat_instr, proj_prod, caseid, other=None, test=False):
    """
    Creates an argo workflow generative name based on the argo
    workflow naming convention. Note that all characters must be
    lowercase and the name must start with an alphanumeric character.

    <user>-<sat.instr>-<project.product>-<timestamp or caseid> \
    -<others>-
    or
    test-<user>-<sat.instr>-<project.product>-<timestamp or caseid> \
    -<others>-

    (https://docs.google.com/document/d/ \
     1s6hq1w60CKnzK6vCkn4ufWCstFLzzxrCIrs-SV3JywU/edit)

    Parameters
    ----------
    user : str
    User string identifier

    sat_instr : str
    Satellite/instrument identifier with period separation
    eg. g16.abi

    proj_prod : str
    Project/product identifier with period separation
    eg. jpssrr.land

    caseid : str or datetime.datetime
    Workflow case identifier. If a string is passed it is used directly
    in the workflow name. If a datetime.datetime is passed it is used
    to generate a timestamp identifier in the form
    "d<YYYYMMDD>t<hhmmsss>"

    other : str
    Any other additional identifier info to be appended to the
    generative name

    test : bool
    Marks a test workflow. False by default, if True "test-" is
    prepended to the workflow name.
    """
    if not isinstance(user, str):
        raise TypeError(f'user:{user} wrong type {type(user)}\n'
                        f'Must be str')
    if not isinstance(sat_instr, str):
        raise TypeError(f'sat_instr:{sat_instr} wrong type {type(sat_instr)}\n'
                        f'Must be str')
    if not isinstance(proj_prod, str):
        raise TypeError(f'proj_prod:{proj_prod} wrong type {type(proj_prod)}\n'
                        f'Must be str')
    if not isinstance(test, bool):
        raise TypeError(f'test:{test} wrong type {type(test)}\n'
                        f'Must be bool')

    wf_name = f'{user}-{sat_instr}-{proj_prod}'
    if test:
        wf_name = f'test-{wf_name}'
    if isinstance(caseid, str):
        wf_name = f'{wf_name}-{caseid}-'
    elif isinstance(caseid, dt):
        wf_name = f'{wf_name}-{caseid.strftime("d%Y%m%dt%H%M%S%f")[:-5]}-'
    else:
        raise TypeError(f'caseid:{caseid} wrong type {type(caseid)}\n'
                        f'Must be str of datetime.datetime')
    if other:
        if not isinstance(other, str):
            raise TypeError(f'other:{other} wrong type {type(other)}\n'
                            f'Must be str')
        wf_name = f'{wf_name}{other}-'
    wf_name = wf_name.lower()

    if not wf_name[0].isalnum():
        raise ValueError(f'wf_name:{wf_name} must start with an alphanumeric '
                         f'character')
    return wf_name


#pylint: disable=too-many-branches
def submit_cmd(exe, template, gen_name=None, params=None, extras=None):
    """
    Creates an argo submit command in the form of a list to be passed
    to the subprocess module.

    Parameters
    ----------
    exe : str or pathlib.Path
    The argo command or the path to the argo binary executable

    template : str or pathlib.Path
    The path to the argo workflow template

    gen_name : str
    The generative name to be passed with argo submit. If None the
    --generate-name option is not included

    params : dict, str, or pathlib.Path
    The parameters to be passed to argo submit. Not included if None.
    If passed as a dict parameters are passed as key/value pairs with
    the -p option, requiring all keys to be str. If passed as a str or
    pathlib.Path it will be passed as a parameter file using the -f
    option.

    extras : list of str
    A list of any additional arguments to be added to the end of the
    command in the form of strings.
    """
    if not isinstance(exe, (str, Path)):
        raise TypeError(f'exe:{exe} wrong type {type(exe)}\n'
                        f'Must be str or pathlib.Path')
    if not isinstance(template, (str, Path)):
        raise TypeError(f'template:{template} wrong type {type(template)}\n'
                        f'Must be str or pathlib.Path')
    if gen_name and not isinstance(gen_name, str):
        raise TypeError(f'gen_name:{gen_name} wrong type {type(gen_name)}\n'
                        f'Must be str')
    if params and not isinstance(params, (dict, str, Path)):
        raise TypeError(f'params:{params} wrong type {type(params)}\n'
                        f'Must be dict, str, or pathlib.Path')
    if isinstance(extras, list):
        for extra in extras:
            if not isinstance(extra, str):
                raise TypeError(f'extra:{extra} wrong type {type(extra)}\n'
                                f'Must be str')
    elif not isinstance(extras, type(None)):
        raise TypeError(f'extras:{extras} wrong type {type(extras)}\n'
                        f'Must be list of strings')

    cmd = [str(exe), 'submit', str(template)]
    if gen_name:
        cmd.extend(['--generate-name', gen_name])
    if isinstance(params, (str, Path)):
        cmd.extend(['-f', str(params)])
    elif params:
        for key, val in params.items():
            if not isinstance(key, str):
                raise TypeError(f'key:{key} wrong type {type(key)}\n'
                                f'All param keys must be str')
            cmd.extend(['-p', f'{key}={val}'])
    if isinstance(extras, list):
        cmd.extend(extras)
    return cmd


def _workflow_filter_kv_dict(keys, line):
    if len(keys) == len(line):
        return dict(zip(keys, line))
    raise ValueError('Mismatched key/value length\n'
                     f'keys : {keys}\n'
                    f'line : {line}')


def workflow_filter(expression, argo_bin='argo', options=None):
    """
    workflow_filter() allows the user to filter and parse the workflows
    returned by the `argo list` shell command using a regular
    expression.

    Parameters
    ----------
    expression : str
    The regex used to filter which workflows to return. If the line
    containing the workflow contains the expression then it will be
    included in the return value.
    Note that this regex does not need to match the whole line. If any
    part of the line matches the regex, it will be included.
    Also note that the regex can match any part of the line, not just
    the workflow's name. This can be used to filter by other fields
    returned by `argo list`. For example, fls workflows with the
    'Running' status can be found with the expression: `r'fls.+Running'`

    argo_bin : str or pathlib.Path
    'argo' by default.
    The command used to call argo. Any string can be used as the
    command. Alternatively, a pathlib.Path object that points to the
    argo binary can be used.

    options : list[str] or None
    None by default.
    The options to add to the `argo list` command, such as
    '--all-namespaces'. If passed as None, no options will be added.
    To add options you can pass in a list of strings that will be added
    to the end of the `argo list` command in order.

    Return
    ------
    A list of dictionaries. Each item in the list represents a workflow
    matched by the passed regular expression. The keys of each
    dictionary are the fields of the `argo list` command matched to each
    workflow. Note that these keys will be generically matched to the
    first line returned by the list command. A ValueError will be raised
    if a matched workflow has a number of fields that do not match the
    number of keys.
    """
    if not isinstance(expression, str):
        raise TypeError(f'expression:{expression} must be str,\n'
                        f'is of type {type(expression)}')
    if not isinstance(argo_bin, (str, Path)):
        raise TypeError(f'argo_bin:{argo_bin} must be str or pathlib.Path,\n'
                        f'is of type {type(argo_bin)}')
    if options and not isinstance(options, list):
        raise TypeError(f'options:{options} must be list,\n'
                        f'is of type {type(options)}')
    if options and not all(isinstance(item, str) for item in options):
        raise TypeError(f'All items of options:{options} must be str')

    cmd = [str(argo_bin), 'list']
    if options:
        cmd.extend(options)
    proc_lines = subprocess.run(cmd, stdout=subprocess.PIPE, check=True) \
                 .stdout.decode('ascii').split('\n')

    keys = proc_lines[0].split()
    match_lines = [line.split()
                   for line in proc_lines[1:]
                   if line and re.search(expression, line)]
    match_dicts = [_workflow_filter_kv_dict(keys, line)
                   for line in match_lines]
    return match_dicts
