"""
nrt_utils.trigger contains functions for handling trigger file
manipulation.
"""
from pathlib import Path
from collections.abc import Iterable


def set_trigger(dir_param, label, status):
    """
    Sets the trigger file to have the given status extension. Any files
    in dir_param that have the given label will be first deleted before
    the new trigger file is created.

    Parameters
    ----------
    dir_param : str or Path
    The directory where the trigger file is to be stored

    label : str
    The unique id for the trigger file

    status : str
    The extension to be attached to the trigger file
    """
    if isinstance(dir_param, (str, Path)):
        trigger_dir = Path(dir_param)
    else:
        raise TypeError(f'dir_param:{dir_param} incorrect type\n'
                        f'Must be str or Path')
    if not isinstance(label, str):
        raise TypeError(f'label:{label} incorrect type\n'
                        f'Must be str')
    if not isinstance(status, str):
        raise TypeError(f'status:{status} incorrect type\n'
                        f'Must be str')
    if not trigger_dir.is_dir():
        raise FileNotFoundError(f'dir_param:{dir_param} inaccessible directory')

    label_files = list(trigger_dir.glob(f'{label}.*'))
    for label_file in label_files:
        label_file.unlink()
    trigger_file = trigger_dir / f'{label}.{status}'
    trigger_file.touch()


def get_labels(dir_param, status_param):
    """
    Returns a list of all labels with the given status as a list of
    strings.

    Parameters
    ----------
    dir_param : str or Path
    The directory where the trigger files are stored

    status_param : str or Iterable of str
    The status(es) of the trigger files to be returned
    Can be passed with glob matching syntax, so "*" will return all
    labels and "stat_[0-9][0-9]" will match both "a.stat_01" and
    "b.stat_02"
    """
    if isinstance(dir_param, (str, Path)):
        trigger_dir = Path(dir_param)
    else:
        raise TypeError(f'dir_param:{dir_param} incorrect type\n'
                        f'Must be str or Path')
    if isinstance(status_param, str):
        status_iter = [status_param]
    elif isinstance(status_param, Iterable):
        for status in status_param:
            if not isinstance(status, str):
                raise TypeError(f'status:{status} incorrect type\n'
                                f'All statuses must be str')
        status_iter = status_param
    else:
        raise TypeError(f'status_param:{status_param} incorrect type\n'
                        f'Must be str or Iterable')
    if not trigger_dir.is_dir():
        raise FileNotFoundError(f'dir_param:{dir_param} inaccessible directory')

    labels = []
    for status in status_iter:
        labels.extend([trigger.stem for trigger \
                       in trigger_dir.glob(f'*.{status}')])
    return labels


def get_status(dir_param, label):
    """
    Returns the status of the trigger file with the given label as a
    string. If no file has the given label, returns None. If multiple
    files have the given label, returns the status of the first found
    file.

    Parameters
    ----------
    dir_param : str or Path
    The directory where the trigger files are stored

    label : str
    The unique id for the trigger file
    """
    if isinstance(dir_param, (str, Path)):
        trigger_dir = Path(dir_param)
    else:
        raise TypeError(f'dir_param:{dir_param} incorrect type\n'
                        f'Must be str or Path')
    if not isinstance(label, str):
        raise TypeError(f'label:{label} incorrect type\n'
                        f'Must be str')
    if not trigger_dir.is_dir():
        raise FileNotFoundError(f'dir_param:{dir_param} inaccessible directory')

    for label_file in trigger_dir.glob(f'{label}.*'):
        return label_file.suffix[1:]
    return None


def rm_labels(dir_param, label_param):
    """
    Deletes any trigger files found in dir_param with the given label.

    Parameters
    ----------
    dir_param : str or Path
    The directory where the trigger files are stored

    label_param : str or Iterable of str
    The unique id(s) of the trigger file(s) to be removed
    Can be passed with glob matching syntax, so "*" will delete all
    labels and "[ab]" will delete both "a.stat_01" and "b.stat_02"
    """
    if isinstance(dir_param, (str, Path)):
        trigger_dir = Path(dir_param)
    else:
        raise TypeError(f'dir_param:{dir_param} incorrect type\n'
                        f'Must be str or Path')
    if isinstance(label_param, str):
        label_iter = [label_param]
    elif isinstance(label_param, Iterable):
        label_iter = label_param
    else:
        raise TypeError(f'label_param:{label_param} incorrect type\n'
                        f'Must be str or Iterable')
    if not trigger_dir.is_dir():
        raise FileNotFoundError(f'dir_param:{dir_param} inaccessible directory')

    for label in label_iter:
        if not isinstance(label, str):
            raise TypeError(f'label:{label} incorrect type\n'
                            f'All labels must be str')
        label_files = list(trigger_dir.glob(f'{label}.*'))
        for label_file in label_files:
            label_file.unlink()


def rm_status(dir_param, status_param):
    """
    Deletes any trigger files found in dir_param with the given status.

    Parameters
    ----------
    dir_param : str or Path
    The directory where the trigger files are stored

    status_param : str or Iterable of str
    The status(es) of the trigger files to be removed
    Can be passed with glob matching syntax, so "*" will delete all
    statuses and "stat_[0-9][0-9]" will delete both "a.stat_01" and
    "b.stat_02"
    """
    if isinstance(dir_param, (str, Path)):
        trigger_dir = Path(dir_param)
    else:
        raise TypeError(f'dir_param:{dir_param} incorrect type\n'
                        f'Must be str or Path')
    if isinstance(status_param, str):
        status_iter = [status_param]
    elif isinstance(status_param, Iterable):
        status_iter = status_param
    else:
        raise TypeError(f'status_param:{status_param} incorrect type\n'
                        f'Must be str or Iterable')
    if not trigger_dir.is_dir():
        raise FileNotFoundError(f'dir_param:{dir_param} inaccessible directory')

    for status in status_iter:
        if not isinstance(status, str):
            raise TypeError(f'status:{status} incorrect type\n'
                            f'All statuses must be str')
        status_files = list(trigger_dir.glob(f'*.{status}'))
        for status_file in status_files:
            status_file.unlink()
