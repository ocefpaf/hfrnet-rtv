"""
time_removal.py provides functions for generalizing removing files from
root directories based on a cutoff time.
"""
import re
from shutil import rmtree
from pathlib import Path
from datetime import datetime as dt, timedelta as td, timezone


def _dt_val(char):
    if char in 'Y':
        val = '[0-9][0-9][0-9][0-9]'
    elif char in 'j':
        val = '[0-9][0-9][0-9]'
    elif char in 'mdHMS':
        val = '[0-9][0-9]'
    elif char in 'f':
        val = '[0-9][0-9][0-9][0-9][0-9][0-9]'
    else:
        raise ValueError(f'Unsupported symbol %{char}')
    return val


def _gen_patterns(globstr):
    gl_patt = ''
    re_patt = '^'
    dt_patt = ''
    marked = False
    for char in globstr:
        if marked:
            dt_val = _dt_val(char)
            re_patt += f'({dt_val})'
            gl_patt += dt_val
            dt_patt += f'%{char}'
            marked = False
        elif char == '%':
            marked = True
        elif char == '*':
            re_patt += '.*'
            gl_patt += '*'
        elif char == '?':
            re_patt += '.'
            gl_patt += '?'
        else:
            re_patt += char
            gl_patt += char
    if marked:
        raise ValueError(f'globstr:{globstr} trailing % character')
    return gl_patt, f'{re_patt}$', dt_patt


def _unpack_root(root):
    if isinstance(root, (str, Path)):
        rootdir = Path(root)
    else:
        raise TypeError(f'root:{root} wrong type {type(root)}\n'
                        f'Must be str or pathlib.Path')
    return rootdir


def _unpack_glob(glob):
    if not isinstance(glob, str):
        raise TypeError(f'glob:{glob} wrong type {type(glob)}\n'
                        f'Must be str')
    return str(Path(glob))


def _unpack_cutoff(cutoff):
    if isinstance(cutoff, dt):
        cutoff_dt = cutoff
    elif isinstance(cutoff, td):
        cutoff_dt = dt.now() - cutoff
    else:
        raise TypeError(f'cutoff:{cutoff} wrong type {type(cutoff)}\n'
                        f'Must be datetime.datetime or datetime.timedelta')
    return cutoff_dt


def cleanup_fn(root, glob, cutoff):
    """
    cleanup_fn removes files or directories that fall before the
    passed cutoff time. The timestamp of a file is parsed through
    its filename given the format of glob, which follows both
    glob pattern matching and datetime.strptime symbol replacement.

    Parameters
    ----------
    root : str or pathlib.Path
    The root directory to match the pattern from

    glob : str
    The pattern to glob with that contains datetime symbol filename
    information.
    Note to only use a given symbol once even if it occurs multiple
    times in the file path (eg. "2020/2020.py" could match "%Y/*.py"
    or "*/%Y.py", but not "%Y/%Y.py").
    The following symbols are currently supported and must use 0 padding: %Y %m %d %j %H %M %S %f

    cutoff : datetime.datetime or datetime.timedelta
    The cutoff time. If the timestamp of a globbed path comes before
    cutoff, the file or directory will be removed. If passed as a
    datetime object, the timestamp will be compared directly to cutoff.
    If passed as a timedelta object, the timestamp will be compared to
    `datetime.datetime.utcnow() - cutoff`.

    Example
    -------
    Given the directory structure:

    /root/data/
      2020_0102/
        1230.dat
        1300.dat
        1330.dat
      2020_0103/
        1230.txt
        1300.txt
        1330.txt
      2020_0104/
        1230.foo
        1300.foo
        1330.foo

    Then the following scripts will result in their accompanied
    directories.

    > cutoff = datetime.datetime(2020, 1, 3, 13, 30)
    > cleanup_fn("/root/data", "%Y_%m%d/%H%M.txt", cutoff)

    /root/data/
      2020_0102/
        1230.dat
        1300.dat
        1330.dat
      2020_0103/
        1330.txt
      2020_0104/
        1230.foo
        1300.foo
        1330.foo

    > cleanup_fn("/root/data", "%Y_%m%d/%H%M.*", cutoff)

    /root/data/
      2020_0102/
      2020_0103/
        1330.txt
      2020_0104/
        1230.foo
        1300.foo
        1330.foo

    > cleanup_fn("/root/data", "%Y_%m%d", cutoff)

    /root/data/
      2020_0104/
        1230.dat
        1300.dat
        1330.dat
    """
    rootdir = _unpack_root(root)
    globstr = _unpack_glob(glob)
    cutoff_dt = _unpack_cutoff(cutoff)
    gl_patt, re_patt, dt_patt = _gen_patterns(globstr)
    re_comp = re.compile(re_patt)
    for sub_path in list(rootdir.glob(gl_patt)):
        dt_str = ''.join(re_comp.match(str(sub_path.relative_to(root))) \
                         .groups())
        path_dt = dt.strptime(dt_str, dt_patt)
        if path_dt < cutoff_dt:
            if sub_path.is_dir():
                rmtree(sub_path)
            else:
                sub_path.unlink()


def cleanup_mt(root, glob, cutoff):
    """
    cleanup_mt removes files or directories that fall before the
    passed cutoff time. The timestamp of a file is parsed through
    its os.stat_result modification time.

    Parameters
    ----------
    root : str or pathlib.Path
    The root directory to match the pattern from.

    glob : str
    The pattern to glob files for removal.

    cutoff : datetime.datetime or datetime.timedelta
    The cutoff time. If the timestamp of a globbed path comes before
    cutoff, the file or directory will be removed. If passed as a
    datetime object, the timestamp will be compared directly to cutoff.
    If passed as a timedelta object, the timestamp will be compared to
    `datetime.datetime.utcnow() - cutoff`.

    Example
    -------
    Given the directory structure with the modification times in
    parentheses:

    /root/data/  (1999/12/31 23:59:59)
      calendar/  (2020/01/01 00:00:00)
        scrp.dat (2020/01/01 00:00:00)
        1300.dat (2020/01/01 00:30:00)
        1330.dat (2020/01/01 01:00:00)
      notes/     (2020/02/01 00:00:00)
        a.txt    (2020/02/01 00:00:00)
        b.txt    (2020/02/02 00:00:00)
        c.txt    (2020/02/03 00:00:00)
      scripts/   (2020/03/01 00:00:00)
        a.py     (2020/03/01 00:00:01)
        b.pl     (2020/03/01 00:00:02)
        c.sh     (2020/03/01 00:00:03)

    Then the following scripts will result in their accompanied
    directories.

    > cutoff = datetime.datetime(2020, 2, 3)
    > cleanup_mt("/root/data", "*/*.txt", cutoff)

    /root/data/  (1999/12/31 23:59:59)
      calendar/  (2020/01/01 00:00:00)
        scrp.dat (2020/01/01 00:00:00)
        1300.dat (2020/01/01 00:30:00)
        1330.dat (2020/01/01 01:00:00)
      notes/     (2020/02/01 00:00:00)
        c.txt    (2020/02/03 00:00:00)
      scripts/   (2020/03/01 00:00:00)
        a.py     (2020/03/01 00:00:01)
        b.pl     (2020/03/01 00:00:02)
        c.sh     (2020/03/01 00:00:03)

    > cleanup_mt("/root/data", "*/*", cutoff)

    /root/data/  (1999/12/31 23:59:59)
      calendar/  (2020/01/01 00:00:00)
      notes/     (2020/02/01 00:00:00)
        c.txt    (2020/02/03 00:00:00)
      scripts/   (2020/03/01 00:00:00)
        a.py     (2020/03/01 00:00:01)
        b.pl     (2020/03/01 00:00:02)
        c.sh     (2020/03/01 00:00:03)

    > cleanup_mt("/root/data", "*", cutoff)

    /root/data/  (1999/12/31 23:59:59)
      scripts/   (2020/03/01 00:00:00)
        a.py     (2020/03/01 00:00:01)
        b.pl     (2020/03/01 00:00:02)
        c.sh     (2020/03/01 00:00:03)
    """
    rootdir = _unpack_root(root)
    globstr = _unpack_glob(glob)
    cutoff_dt = _unpack_cutoff(cutoff)
    content = list(rootdir.glob(globstr))
    for sub_path in content:
        # Get target creation timestamp
        path_dt = dt.fromtimestamp(sub_path.stat().st_mtime)
        # If diff is less than 0 then the target is newer than the cutoff
        # Changed because datetime - datetime => deltatime
        diff = path_dt - cutoff_dt
        if diff.total_seconds() < 0:
            if sub_path.is_dir():
                rmtree(sub_path)
            else:
                sub_path.unlink()
