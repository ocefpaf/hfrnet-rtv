"""
The call_limit module provides functionality for looping over function
calls while limiting the number of calls made. Currently this entirely
lies with the call_limit decorator. This is particularly useful when
limiting the number of argo workflows submitted at a given time.
"""


#pylint: disable=broad-except
def call_limit(count_limit, catch=True, short_circuit=True):
    """
    call_limit() acts as a decorator for wrapping functions you wish
    to call multiple times under a certain limit.

    When decorating the function definition 'foo()' to be called no
    more than 10 times, this can be done with the following syntax:

    @call_limit(10)
    def foo():
        ...

    Alternatively, the function can be decorated at runtime like so:

    call_limit(10)(foo)()

    Each call to the wrapped function will be made with the same
    parameters, so any varying behavior desired over function calls
    must account for this.

    Additionally, assuming short_circuit=True, the wrapped function
    must have two return values:
    1. A boolean value signalling if additional function can be made.
       If set to True, an additional call will be made if the call
       limit has not been reached. If set to False, no additional
       calls will be made even if the call limit has not been reached.
    2. Any additional value that the function wishes to return. If
       multiple values are to be returned then they must be wrapped in
       a single data structure like a tuple. The values returned here
       will populate the list returned by the decorated function. If no
       value is intended to be populated here, it can be set to None,
       but there must be a second return value if short_circuit=True.

    Parameters
    ----------
    count_limit : int
        The maximum number of calls that can be made of the wrapped
        function.

    catch : boolean
        True by default.
        If True, the exception will be stored in the returned list and
        execution will continue.
        If False, an exception raised by the wrapped function will not
        be caught.

    short_circuit : boolean
        True by default.
        If True, the first returned value of the wrapped function will
        mark if execution should continue and the second return value
        will be added to the return list. This behavior is described
        above.
        If False, the wrapped function will be treated as having a
        single return value which will be added to the return list.

    Return
    ------
    The decorated function will return a list containing the result of
    each iteration of the function in order. If short_circuit=True, this
    will be populated by the second return value of the function. If
    short_circuit=False, this will be populated by the single return
    value of the function. If catch=True, this list may also be
    populated by any exceptions raised by the function.
    """
    if not isinstance(count_limit, int):
        raise TypeError(f'count_limit:{count_limit} is of type '
                        f'{type(count_limit)},\n'
                        f'must be of type int')
    def outer(func):
        if not callable(func):
            raise TypeError(f'func:{func} not callable')
        def inner(*args, **kwargs):
            count = 0
            continue_check = True
            return_values = []
            while count < count_limit and continue_check:
                count += 1
                try:
                    if short_circuit:
                        continue_check, return_val = func(*args, **kwargs)
                    else:
                        return_val = func(*args, **kwargs)
                except Exception as exp:
                    if not catch:
                        raise exp
                    return_values.append(exp)
                else:
                    return_values.append(return_val)
            return return_values
        return inner
    return outer
